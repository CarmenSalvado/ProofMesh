// See all configuration options: https://remotion.dev/docs/config
// Each option also is available as a CLI flag: https://remotion.dev/docs/cli

// Note: When using the Node.JS APIs, the config file doesn't apply. Instead, pass options directly to the APIs

import { Config } from "@remotion/cli/config";
import { enableTailwind } from '@remotion/tailwind-v4';
import path from "path";

Config.setPort(3001);
Config.setVideoImageFormat("jpeg");
Config.setOverwriteOutput(true);
Config.overrideWebpackConfig((config) => {
  const nextConfig = enableTailwind(config);
  nextConfig.resolve = nextConfig.resolve ?? {};
  nextConfig.resolve.alias = {
    ...(nextConfig.resolve.alias ?? {}),
    "@": path.resolve(process.cwd(), "../frontend/src"),
  };
  return nextConfig;
});
