import React from "react";
import { AbsoluteFill, Easing, interpolate, useCurrentFrame } from "remotion";
declare const require: (id: string) => unknown;

const { ProofCanvasV2 } = require("../../frontend/src/components/canvas/ProofCanvasV2") as {
  ProofCanvasV2: React.ComponentType<Record<string, unknown>>;
};

export const PROOFCANVAS_V2_GIF_DURATION = 180;

const BASE_NODES = [
  {
    id: "def-prime",
    type: "DEFINITION",
    title: "Prime Number",
    formula: "$n \\in \\mathbb{N}, n > 1$",
    x: 220,
    y: 92,
    width: 280,
    status: "DRAFT",
    dependencies: [],
  },
  {
    id: "lem-euclid",
    type: "LEMMA",
    title: "Euclid's Construction",
    content: "$N = p_1 \\cdots p_n + 1$",
    x: 780,
    y: 88,
    width: 290,
    status: "VERIFIED",
    dependencies: [],
  },
  {
    id: "thm-inf",
    type: "THEOREM",
    title: "Infinitude of Primes",
    formula: "$\\exists^\\infty p : \\mathrm{Prime}(p)$",
    x: 520,
    y: 300,
    width: 320,
    status: "PROPOSED",
    dependencies: [],
  },
  {
    id: "formal-check",
    type: "FORMAL_TEST",
    title: "Lean Verification",
    content: "lean-runner> theorem `prime_infinite` compiled.",
    x: 120,
    y: 430,
    width: 330,
    status: "DRAFT",
    dependencies: [],
  },
];

const EDGES = [
  { id: "edge-1", from: "def-prime", to: "thm-inf", type: "implies" },
  { id: "edge-2", from: "lem-euclid", to: "thm-inf", type: "implies" },
  { id: "edge-3", from: "formal-check", to: "thm-inf", type: "references" },
];

export const ProofCanvasV2Gif: React.FC = () => {
  const frame = useCurrentFrame();
  const thmX = interpolate(frame, [0, 72, 132, PROOFCANVAS_V2_GIF_DURATION], [520, 552, 536, 520], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
    easing: Easing.inOut(Easing.cubic),
  });
  const thmY = interpolate(frame, [0, 72, 132, PROOFCANVAS_V2_GIF_DURATION], [300, 278, 286, 300], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
    easing: Easing.inOut(Easing.cubic),
  });
  const formalY = interpolate(frame, [0, 84, 132, PROOFCANVAS_V2_GIF_DURATION], [430, 456, 444, 430], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
    easing: Easing.inOut(Easing.quad),
  });
  const selectedNodeId =
    frame < 48 ? "def-prime" : frame < 96 ? "lem-euclid" : frame < 144 ? "formal-check" : "thm-inf";

  const nodes = BASE_NODES.map((node) => {
    if (node.id === "thm-inf") {
      return {
        ...node,
        x: thmX,
        y: thmY,
        status: frame > 132 ? "VERIFIED" : "PROPOSED",
      };
    }
    if (node.id === "formal-check") {
      return {
        ...node,
        y: formalY,
        status: frame > 72 ? "VERIFIED" : "DRAFT",
      };
    }
    if (node.id === "def-prime") {
      return {
        ...node,
        status: frame > 24 ? "VERIFIED" : "DRAFT",
      };
    }
    return node;
  });

  return (
    <AbsoluteFill
      style={{
        background: "#f5f5f5",
        padding: 20,
        fontFamily: "var(--font-geist-pixel-square)",
      }}
    >
      <div
        style={{
          position: "absolute",
          left: 28,
          top: 32,
          zIndex: 40,
          border: "1px solid #d4d4d8",
          borderRadius: 999,
          padding: "8px 14px",
          backgroundColor: "rgba(255,255,255,0.9)",
          fontFamily: "var(--font-geist-pixel-square)",
          fontSize: 21,
          color: "#1f2937",
        }}
      >
        From Idea to Verified Proof
      </div>

      <div
        style={{
          position: "absolute",
          inset: 18,
          borderRadius: 20,
          overflow: "hidden",
          border: "1px solid #e4e4e7",
          backgroundColor: "#fafafa",
          boxShadow: "0 22px 70px -40px rgba(0,0,0,0.35)",
          fontFamily: "var(--font-geist-pixel-square)",
        }}
      >
        <ProofCanvasV2
          nodes={nodes}
          edges={EDGES}
          selectedNodeId={selectedNodeId}
          onNodeSelect={() => undefined}
          readOnly={true}
          disableInteraction={true}
          hideZoomControls={true}
          hideMinimap={true}
          hideHelpText={true}
        />
      </div>
    </AbsoluteFill>
  );
};
