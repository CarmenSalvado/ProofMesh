/* eslint-disable @remotion/non-pure-animation */
import "./index.css";
import { Composition } from "remotion";
import { TransitionSeries, linearTiming } from "@remotion/transitions";
import { fade } from "@remotion/transitions/fade";
import { slide } from "@remotion/transitions/slide";

// Sections
import { HookSection } from "./sections/HookSection";
import { ProblemSection } from "./sections/ProblemSection";
import { SolutionSection } from "./sections/SolutionSection";
import { CoreDemoSection } from "./sections/CoreDemoSection";
import { PlatformSection } from "./sections/PlatformSection";
import { GeminiSection } from "./sections/GeminiSection";
import { ClosingSection } from "./sections/ClosingSection";

// Frame calculations (at 30fps)
const FPS = 30;

// Section durations based on the script:
// 1. Hook: 0-10s (300 frames)
// 2. Problem: 10-25s (450 frames)
// 3. Solution: 25-45s (600 frames)
// 4. Core Demo: 45-90s (1350 frames)
// 5. Platform: 90-110s (600 frames)
// 6. Gemini: 110-130s (600 frames)
// 7. Closing: 130-150s (600 frames)

// Static configuration - not an animation
const SECTIONS = {
  hook: { duration: 300, transition: 15 },
  problem: { duration: 450, transition: 15 },
  solution: { duration: 600, transition: 15 },
  coreDemo: { duration: 1350, transition: 20 },
  platform: { duration: 600, transition: 15 },
  gemini: { duration: 600, transition: 15 },
  closing: { duration: 600, transition: 0 },
} as const;

// Calculate total duration accounting for transitions
const calculateTotalDuration = () => {
  let total = 0;
  total += SECTIONS.hook.duration;
  total += SECTIONS.problem.duration;
  total += SECTIONS.solution.duration;
  total += SECTIONS.coreDemo.duration;
  total += SECTIONS.platform.duration;
  total += SECTIONS.gemini.duration;
  total += SECTIONS.closing.duration;
  
  // Subtract all transitions (they overlap)
  const totalTransitions = 
    SECTIONS.hook.transition +
    SECTIONS.problem.transition +
    SECTIONS.solution.transition +
    SECTIONS.coreDemo.transition +
    SECTIONS.platform.transition +
    SECTIONS.gemini.transition +
    SECTIONS.closing.transition;
  return total - totalTransitions;
};

const TOTAL_DURATION = calculateTotalDuration();

export const RemotionRoot: React.FC = () => {
  return (
    <>
      {/* Main ProofMesh Demo Composition */}
      <Composition
        id="ProofMeshDemo"
        component={ProofMeshDemo}
        durationInFrames={TOTAL_DURATION}
        fps={FPS}
        width={1920}
        height={1080}
        defaultProps={{
          showTransitions: true,
        }}
      />

      {/* Individual section compositions for testing */}
      <Composition
        id="01-Hook"
        component={HookSection}
        durationInFrames={SECTIONS.hook.duration}
        fps={FPS}
        width={1920}
        height={1080}
      />

      <Composition
        id="02-Problem"
        component={ProblemSection}
        durationInFrames={SECTIONS.problem.duration}
        fps={FPS}
        width={1920}
        height={1080}
      />

      <Composition
        id="03-Solution"
        component={SolutionSection}
        durationInFrames={SECTIONS.solution.duration}
        fps={FPS}
        width={1920}
        height={1080}
      />

      <Composition
        id="04-CoreDemo"
        component={CoreDemoSection}
        durationInFrames={SECTIONS.coreDemo.duration}
        fps={FPS}
        width={1920}
        height={1080}
      />

      <Composition
        id="05-Platform"
        component={PlatformSection}
        durationInFrames={SECTIONS.platform.duration}
        fps={FPS}
        width={1920}
        height={1080}
      />

      <Composition
        id="06-Gemini"
        component={GeminiSection}
        durationInFrames={SECTIONS.gemini.duration}
        fps={FPS}
        width={1920}
        height={1080}
      />

      <Composition
        id="07-Closing"
        component={ClosingSection}
        durationInFrames={SECTIONS.closing.duration}
        fps={FPS}
        width={1920}
        height={1080}
      />
    </>
  );
};

// Main demo composition with all sections
const ProofMeshDemo: React.FC<{ showTransitions?: boolean }> = ({
  showTransitions = true,
}) => {
  if (!showTransitions) {
    return <HookSection />;
  }

  return (
    <TransitionSeries>
      {/* 1. Hook - 0-10s */}
      <TransitionSeries.Sequence durationInFrames={SECTIONS.hook.duration}>
        <HookSection />
      </TransitionSeries.Sequence>

      <TransitionSeries.Transition
        presentation={fade()}
        timing={linearTiming({ durationInFrames: SECTIONS.hook.transition })}
      />

      {/* 2. Problem - 10-25s */}
      <TransitionSeries.Sequence durationInFrames={SECTIONS.problem.duration}>
        <ProblemSection />
      </TransitionSeries.Sequence>

      <TransitionSeries.Transition
        presentation={slide({ direction: "from-right" })}
        timing={linearTiming({ durationInFrames: SECTIONS.problem.transition })}
      />

      {/* 3. Solution - 25-45s */}
      <TransitionSeries.Sequence durationInFrames={SECTIONS.solution.duration}>
        <SolutionSection />
      </TransitionSeries.Sequence>

      <TransitionSeries.Transition
        presentation={fade()}
        timing={linearTiming({ durationInFrames: SECTIONS.solution.transition })}
      />

      {/* 4. Core Demo - 45-90s */}
      <TransitionSeries.Sequence durationInFrames={SECTIONS.coreDemo.duration}>
        <CoreDemoSection />
      </TransitionSeries.Sequence>

      <TransitionSeries.Transition
        presentation={slide({ direction: "from-bottom" })}
        timing={linearTiming({ durationInFrames: SECTIONS.coreDemo.transition })}
      />

      {/* 5. Platform - 90-110s */}
      <TransitionSeries.Sequence durationInFrames={SECTIONS.platform.duration}>
        <PlatformSection />
      </TransitionSeries.Sequence>

      <TransitionSeries.Transition
        presentation={fade()}
        timing={linearTiming({ durationInFrames: SECTIONS.platform.transition })}
      />

      {/* 6. Gemini - 110-130s */}
      <TransitionSeries.Sequence durationInFrames={SECTIONS.gemini.duration}>
        <GeminiSection />
      </TransitionSeries.Sequence>

      <TransitionSeries.Transition
        presentation={slide({ direction: "from-left" })}
        timing={linearTiming({ durationInFrames: SECTIONS.gemini.transition })}
      />

      {/* 7. Closing - 130-150s */}
      <TransitionSeries.Sequence durationInFrames={SECTIONS.closing.duration}>
        <ClosingSection />
      </TransitionSeries.Sequence>
    </TransitionSeries>
  );
};
