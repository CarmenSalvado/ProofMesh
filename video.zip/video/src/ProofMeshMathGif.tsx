import React from "react";
import {
	AbsoluteFill,
	Easing,
	interpolate,
	spring,
	useCurrentFrame,
	useVideoConfig,
} from "remotion";

export type ProofMeshMathGifProps = {
	title?: string;
	subtitle?: string;
	accentColor?: string;
};

export const PROOFMESH_MATH_GIF_DURATION = 150;

type SymbolSpec = {
	char: string;
	left: string;
	top: string;
	size: number;
	driftX: number;
	driftY: number;
	delay: number;
	spin: number;
	color: string;
	glow: string;
};

const SYMBOLS: SymbolSpec[] = [
	{ char: "∫", left: "8%", top: "13%", size: 86, driftX: 14, driftY: 8, delay: 0, spin: -6, color: "rgba(99,102,241,0.62)", glow: "99,102,241" },
	{ char: "cos", left: "22%", top: "12%", size: 54, driftX: 10, driftY: 7, delay: 5, spin: -4, color: "rgba(244,63,94,0.5)", glow: "244,63,94" },
	{ char: "≈", left: "39%", top: "11%", size: 58, driftX: 9, driftY: 7, delay: 9, spin: 4, color: "rgba(14,165,233,0.52)", glow: "14,165,233" },
	{ char: "∑", left: "80%", top: "14%", size: 62, driftX: -12, driftY: 8, delay: 7, spin: 5, color: "rgba(99,102,241,0.48)", glow: "99,102,241" },
	{ char: "√", left: "88%", top: "15%", size: 84, driftX: -13, driftY: 8, delay: 3, spin: 5, color: "rgba(6,182,212,0.62)", glow: "6,182,212" },
	{ char: "∞", left: "10%", top: "74%", size: 72, driftX: 10, driftY: -8, delay: 12, spin: -5, color: "rgba(99,102,241,0.52)", glow: "99,102,241" },
	{ char: "dx", left: "28%", top: "82%", size: 56, driftX: 7, driftY: -6, delay: 16, spin: -4, color: "rgba(245,158,11,0.5)", glow: "245,158,11" },
	{ char: "lim", left: "72%", top: "82%", size: 54, driftX: -7, driftY: -6, delay: 19, spin: 4, color: "rgba(59,130,246,0.5)", glow: "59,130,246" },
];

const typedSlice = (text: string, frame: number, start: number, speed: number) => {
	const chars = Math.floor((frame - start) * speed);
	if (chars <= 0) return "";
	return text.slice(0, Math.min(text.length, chars));
};

const FloatingSymbols: React.FC = () => {
	const frame = useCurrentFrame();
	const { fps } = useVideoConfig();

	return (
		<>
			{SYMBOLS.map((spec, index) => {
				const local = frame - spec.delay;
				const intro = interpolate(local, [0, 12], [0, 1], {
					extrapolateLeft: "clamp",
					extrapolateRight: "clamp",
					easing: Easing.out(Easing.cubic),
				});
				const outro = interpolate(
					local,
					[PROOFMESH_MATH_GIF_DURATION - 28, PROOFMESH_MATH_GIF_DURATION - 8],
					[1, 0],
					{
						extrapolateLeft: "clamp",
						extrapolateRight: "clamp",
						easing: Easing.in(Easing.cubic),
					},
				);
				const waveX = Math.sin((local / fps) * 2.1 + index) * spec.driftX;
				const waveY = Math.cos((local / fps) * 1.9 + index * 0.8) * spec.driftY;
				const twist = Math.sin((local / fps) * 1.6 + index) * spec.spin;
				const glowPulse = 0.2 + Math.sin((local + index * 8) / 14) * 0.08;
				const opacity = intro * outro;

				return (
					<span
						key={`${spec.char}-${index}`}
						style={{
							position: "absolute",
							left: spec.left,
							top: spec.top,
							fontFamily: "var(--font-geist-pixel-square)",
							fontSize: spec.size,
								color: spec.color,
								opacity: opacity * 0.88,
								transform: `translate(${waveX}px, ${waveY}px) rotate(${twist}deg)`,
									textShadow: `0 0 8px rgba(${spec.glow}, ${glowPulse})`,
								userSelect: "none",
								pointerEvents: "none",
						}}
					>
						{spec.char}
					</span>
				);
			})}
		</>
	);
};

export const ProofMeshMathGif: React.FC<ProofMeshMathGifProps> = ({
	title = "ProofMesh",
	subtitle = "Collaborative math proving",
	accentColor = "#4338ca",
}) => {
	const frame = useCurrentFrame();
	const { fps } = useVideoConfig();
	const intro = spring({
		frame,
		fps,
		config: {
			damping: 120,
			stiffness: 170,
			mass: 0.7,
		},
	});
	const outro = interpolate(
		frame,
		[PROOFMESH_MATH_GIF_DURATION - 18, PROOFMESH_MATH_GIF_DURATION],
		[1, 0],
		{
			extrapolateLeft: "clamp",
			extrapolateRight: "clamp",
			easing: Easing.in(Easing.cubic),
		},
	);
	const overlayPulse = 0.46 + Math.sin(frame / 22) * 0.08;
	const titleText = typedSlice(title, frame, 4, 1.6);
	const subtitleText = typedSlice(subtitle, frame, 24, 1.0);
	const subtitle2Text = typedSlice("AI-assisted verification", frame, 42, 0.95);
	const titleKick = 1 + interpolate(frame, [12, 20, 34], [0, 0.07, 0], {
		extrapolateLeft: "clamp",
		extrapolateRight: "clamp",
		easing: Easing.out(Easing.cubic),
	});

	return (
		<AbsoluteFill style={{ backgroundColor: "#f5f5f5", overflow: "hidden" }}>
			<div
				style={{
					position: "absolute",
					inset: 0,
					background:
						"radial-gradient(circle at 22% 18%, rgba(99,102,241,0.2) 0%, rgba(255,255,255,0.28) 52%), radial-gradient(circle at 82% 80%, rgba(6,182,212,0.18) 0%, rgba(255,255,255,0.24) 56%), linear-gradient(160deg, #f5f5f5 0%, #ffffff 46%, #f3f4f6 100%)",
				}}
			/>

			<div
				style={{
					position: "absolute",
					inset: 0,
					background:
						"linear-gradient(180deg, rgba(255,255,255,0.58) 0%, rgba(255,255,255,0.12) 44%, rgba(255,255,255,0.68) 100%)",
					opacity: overlayPulse,
				}}
			/>

			<FloatingSymbols />

			<AbsoluteFill
				style={{
					alignItems: "center",
					justifyContent: "center",
					padding: "0 84px",
					textAlign: "center",
					transform: `scale(${intro * titleKick})`,
					opacity: intro * outro,
				}}
			>
				<div
					style={{
						maxWidth: 1080,
						borderRadius: 32,
						border: "1px solid rgba(255,255,255,0.65)",
						backgroundColor: "rgba(255,255,255,0.7)",
						padding: "46px 44px 34px",
						boxShadow: "0 16px 45px -30px rgba(0,0,0,0.35)",
						backdropFilter: "blur(2px)",
					}}
				>
					<div
						style={{
						fontFamily: "var(--font-geist-pixel-square)",
						fontSize: 154,
						lineHeight: 0.9,
						letterSpacing: "-0.04em",
						color: "#0a0a0a",
							textShadow: "0 6px 14px rgba(0,0,0,0.1)",
					}}
					>
						{titleText}
					</div>
					<div
						style={{
							marginTop: 18,
							fontFamily: "var(--font-geist-pixel-square)",
							fontSize: 44,
							fontWeight: 700,
							lineHeight: 1.02,
							letterSpacing: "-0.015em",
							color: "#171717",
								textShadow: "0 4px 10px rgba(0,0,0,0.08)",
						}}
					>
						{subtitleText}
					</div>
					<div
						style={{
							marginTop: 8,
							display: "inline-block",
							padding: "0 8px",
							fontFamily: "var(--font-geist-pixel-square)",
							fontSize: 40,
							fontWeight: 700,
							lineHeight: 1.04,
							letterSpacing: "-0.01em",
							color: "#171717",
							background:
								"linear-gradient(180deg, transparent 56%, rgba(59,130,246,0.34) 56%)",
						}}
					>
						{subtitle2Text}
					</div>
					<div
						style={{
							marginTop: 18,
							fontFamily: "var(--font-geist-pixel-square)",
							fontSize: 26,
							fontWeight: 700,
							letterSpacing: "-0.01em",
							color: accentColor,
						}}
					>
						Built for Gemini 3 Hackathon 2026
					</div>
				</div>
			</AbsoluteFill>
		</AbsoluteFill>
	);
};
