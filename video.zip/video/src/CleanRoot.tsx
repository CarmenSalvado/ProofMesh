import "./index.css";
import { Composition, staticFile, Audio } from "remotion";
import { TransitionSeries, linearTiming } from "@remotion/transitions";
import { fade } from "@remotion/transitions/fade";
import { slide } from "@remotion/transitions/slide";

// Components
import { CleanLogo } from "./components/CleanLogo";
import { TextSlide } from "./components/TextSlide";
import { AppClipPlaceholder } from "./components/AppClipPlaceholder";
import { VibrantMinimalDemo, VIBRANT_MINIMAL_DURATION } from "./VibrantMinimalDemo";
import {
  ProofMeshMathGif,
  PROOFMESH_MATH_GIF_DURATION,
} from "./ProofMeshMathGif";
import {
  ProofCanvasV2Gif,
  PROOFCANVAS_V2_GIF_DURATION,
} from "./ProofCanvasV2Gif";

// Frame calculations (at 30fps)
const FPS = 30;

// OPTIMIZED: Much faster durations (in frames)
// Original: ~2 minutes (3600 frames)
// New: ~35 seconds (1050 frames)
const SECTIONS = {
  logo: { duration: 90, transition: 10 },        // 3s (was 15s)
  slide1: { duration: 75, transition: 8 },       // 2.5s (was 12s)
  slide2: { duration: 75, transition: 8 },       // 2.5s
  slide3: { duration: 75, transition: 8 },       // 2.5s
  slide4: { duration: 75, transition: 8 },       // 2.5s
  slide5: { duration: 75, transition: 8 },       // 2.5s
  clip1: { duration: 120, transition: 10 },      // 4s (was 20s)
  clip2: { duration: 120, transition: 10 },      // 4s
  closing: { duration: 60, transition: 0 },      // 2s (was 10s)
} as const;

// Calculate total duration
const calculateTotalDuration = () => {
  let total = 0;
  Object.values(SECTIONS).forEach((section) => {
    total += section.duration;
  });
  
  // Subtract transitions (they overlap)
  const totalTransitions = Object.values(SECTIONS).reduce(
    (acc, section) => acc + section.transition,
    0
  );
  return total - totalTransitions;
};

const TOTAL_DURATION = calculateTotalDuration();

export const CleanRemotionRoot: React.FC = () => {
  return (
    <>
      <Composition
        id="VibrantMinimalClips"
        component={VibrantMinimalDemo}
        durationInFrames={VIBRANT_MINIMAL_DURATION}
        fps={FPS}
        width={1920}
        height={1080}
        defaultProps={{
          audioSrc: "/music.mp3",
          // Drop your recorded clips in `video/public/clips/`
          // and set the `src` below, e.g. "/clips/canvas.mp4".
          clips: [
            { label: "Canvas exploration" },
            { label: "Discussion and critique" },
            { label: "Lean verification pass" },
          ],
        }}
      />

      <Composition
        id="ProofMeshMathGif"
        component={ProofMeshMathGif}
        durationInFrames={PROOFMESH_MATH_GIF_DURATION}
        fps={FPS}
        width={1280}
        height={720}
        defaultProps={{
          title: "ProofMesh",
          subtitle: "Collaborative math proving",
          accentColor: "#4338ca",
        }}
      />

      <Composition
        id="ProofCanvasV2Gif"
        component={ProofCanvasV2Gif}
        durationInFrames={PROOFCANVAS_V2_GIF_DURATION}
        fps={FPS}
        width={1280}
        height={720}
      />

      {/* Main Composition - FAST with MUSIC */}
      <Composition
        id="CleanDemo"
        component={CleanDemo}
        durationInFrames={TOTAL_DURATION}
        fps={FPS}
        width={1920}
        height={1080}
        defaultProps={{
          audioSrc: "/music.mp3",
        }}
      />

      {/* Individual section compositions for testing */}
      <Composition
        id="01-Logo"
        component={CleanLogo}
        durationInFrames={SECTIONS.logo.duration}
        fps={FPS}
        width={1920}
        height={1080}
      />

      <Composition
        id="02-Slide1"
        component={() => (
          <TextSlide
            title="Math is still done"
            subtitle="like in the 1800s"
          />
        )}
        durationInFrames={SECTIONS.slide1.duration}
        fps={FPS}
        width={1920}
        height={1080}
      />

      <Composition
        id="03-Slide2"
        component={() => (
          <TextSlide
            title="ProofMesh"
            subtitle="Turns ideas into verified knowledge"
          />
        )}
        durationInFrames={SECTIONS.slide2.duration}
        fps={FPS}
        width={1920}
        height={1080}
      />

      <Composition
        id="04-Slide3"
        component={() => (
          <TextSlide
            title="Powered by AI"
            subtitle="Gemini + Lean 4 verification"
          />
        )}
        durationInFrames={SECTIONS.slide3.duration}
        fps={FPS}
        width={1920}
        height={1080}
      />

      <Composition
        id="05-Slide4"
        component={() => (
          <TextSlide
            title="Collaborative"
            subtitle="Real-time math with your team"
          />
        )}
        durationInFrames={SECTIONS.slide4.duration}
        fps={FPS}
        width={1920}
        height={1080}
      />

      <Composition
        id="06-Slide5"
        component={() => (
          <TextSlide
            title="Get Started"
            subtitle="Join the future of mathematics"
          />
        )}
        durationInFrames={SECTIONS.slide5.duration}
        fps={FPS}
        width={1920}
        height={1080}
      />

      <Composition
        id="07-AppDemo1"
        component={() => (
          <AppClipPlaceholder
            title="Canvas Demo"
            description="Replace with actual screen recording"
          />
        )}
        durationInFrames={SECTIONS.clip1.duration}
        fps={FPS}
        width={1920}
        height={1080}
      />

      <Composition
        id="08-AppDemo2"
        component={() => (
          <AppClipPlaceholder
            title="Collaboration Demo"
            description="Replace with actual screen recording"
          />
        )}
        durationInFrames={SECTIONS.clip2.duration}
        fps={FPS}
        width={1920}
        height={1080}
      />

      <Composition
        id="09-Closing"
        component={() => <CleanLogo showText={true} />}
        durationInFrames={SECTIONS.closing.duration}
        fps={FPS}
        width={1920}
        height={1080}
      />
    </>
  );
};

// Main demo composition with all sections and AUDIO
const CleanDemo: React.FC<{
  audioSrc?: string;
}> = ({ audioSrc }) => {
  return (
    <>
      {/* Background Music */}
      {audioSrc && (
        <Audio
          src={staticFile(audioSrc)}
          volume={0.4}
          loop
        />
      )}
      
      <TransitionSeries>
        {/* 1. Logo - 3s */}
        <TransitionSeries.Sequence durationInFrames={SECTIONS.logo.duration}>
          <CleanLogo showText={true} />
        </TransitionSeries.Sequence>

        <TransitionSeries.Transition
          presentation={fade()}
          timing={linearTiming({ durationInFrames: SECTIONS.logo.transition })}
        />

        {/* 2. Slide 1 - 2.5s */}
        <TransitionSeries.Sequence durationInFrames={SECTIONS.slide1.duration}>
          <TextSlide
            title="Math is still done"
            subtitle="like in the 1800s"
          />
        </TransitionSeries.Sequence>

        <TransitionSeries.Transition
          presentation={slide({ direction: "from-right" })}
          timing={linearTiming({ durationInFrames: SECTIONS.slide1.transition })}
        />

        {/* 3. Slide 2 - 2.5s */}
        <TransitionSeries.Sequence durationInFrames={SECTIONS.slide2.duration}>
          <TextSlide
            title="ProofMesh"
            subtitle="Turns ideas into verified knowledge"
          />
        </TransitionSeries.Sequence>

        <TransitionSeries.Transition
          presentation={fade()}
          timing={linearTiming({ durationInFrames: SECTIONS.slide2.transition })}
        />

        {/* 4. Slide 3 - 2.5s */}
        <TransitionSeries.Sequence durationInFrames={SECTIONS.slide3.duration}>
          <TextSlide
            title="Powered by AI"
            subtitle="Gemini + Lean 4 verification"
          />
        </TransitionSeries.Sequence>

        <TransitionSeries.Transition
          presentation={slide({ direction: "from-left" })}
          timing={linearTiming({ durationInFrames: SECTIONS.slide3.transition })}
        />

        {/* 5. Slide 4 - 2.5s */}
        <TransitionSeries.Sequence durationInFrames={SECTIONS.slide4.duration}>
          <TextSlide
            title="Collaborative"
            subtitle="Real-time math with your team"
          />
        </TransitionSeries.Sequence>

        <TransitionSeries.Transition
          presentation={fade()}
          timing={linearTiming({ durationInFrames: SECTIONS.slide4.transition })}
        />

        {/* 6. Slide 5 - 2.5s */}
        <TransitionSeries.Sequence durationInFrames={SECTIONS.slide5.duration}>
          <TextSlide
            title="Get Started"
            subtitle="Join the future of mathematics"
          />
        </TransitionSeries.Sequence>

        <TransitionSeries.Transition
          presentation={slide({ direction: "from-bottom" })}
          timing={linearTiming({ durationInFrames: SECTIONS.slide5.transition })}
        />

        {/* 7. App Clip 1 - 4s */}
        <TransitionSeries.Sequence durationInFrames={SECTIONS.clip1.duration}>
          <AppClipPlaceholder
            title="Canvas Demo"
            description="Replace with actual screen recording"
          />
        </TransitionSeries.Sequence>

        <TransitionSeries.Transition
          presentation={fade()}
          timing={linearTiming({ durationInFrames: SECTIONS.clip1.transition })}
        />

        {/* 8. App Clip 2 - 4s */}
        <TransitionSeries.Sequence durationInFrames={SECTIONS.clip2.duration}>
          <AppClipPlaceholder
            title="Collaboration Demo"
            description="Replace with actual screen recording"
          />
        </TransitionSeries.Sequence>

        <TransitionSeries.Transition
          presentation={fade()}
          timing={linearTiming({ durationInFrames: SECTIONS.clip2.transition })}
        />

        {/* 9. Closing - 2s */}
        <TransitionSeries.Sequence durationInFrames={SECTIONS.closing.duration}>
          <CleanLogo showText={true} />
        </TransitionSeries.Sequence>
      </TransitionSeries>
    </>
  );
};
