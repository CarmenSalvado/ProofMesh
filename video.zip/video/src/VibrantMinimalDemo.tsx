import React from "react";
import {
	AbsoluteFill,
	Audio,
	Easing,
	OffthreadVideo,
	Series,
	interpolate,
	staticFile,
	useCurrentFrame,
} from "remotion";

export type ClipSpec = {
	label: string;
	src?: string;
};

// Put your screen recordings in `video/public/clips/`
// and reference them as `src: "/clips/your-clip.mp4"`.

const ACTS = {
	opener: 78,
	tension: 90,
	canvas: 186,
	questionA: 72,
	verify: 186,
	questionB: 72,
	collab: 186,
	questionC: 72,
	climax: 96,
	outro: 84,
} as const;

export const VIBRANT_MINIMAL_DURATION = Object.values(ACTS).reduce(
	(total, duration) => total + duration,
	0,
);

const fallbackClips: ClipSpec[] = [
	{ label: "Canvas exploration" },
	{ label: "Discussion and critique" },
	{ label: "Lean verification pass" },
];

type OverlayLine = {
	text: string;
	from: number;
};

type QuestionScene = {
	prefix: string;
	highlight: string;
	suffix: string;
	accent: string;
};

const clipText: Record<"canvas" | "verify" | "collab", OverlayLine[]> = {
	canvas: [
		{ text: "Map the proof as a living graph.", from: 18 },
		{ text: "Branch ideas without losing context.", from: 94 },
	],
	verify: [
		{ text: "Ask Rho for critique in flow.", from: 16 },
		{ text: "Lean checks every key claim.", from: 92 },
	],
	collab: [
		{ text: "Discuss, formalize, and iterate together.", from: 16 },
		{ text: "One shared thread from idea to proof.", from: 92 },
	],
};

const questionScenes: QuestionScene[] = [
	{
		prefix: "What breaks before",
		highlight: "machine-check",
		suffix: "?",
		accent: "#67e8f9",
	},
	{
		prefix: "Can this be",
		highlight: "verified now",
		suffix: "?",
		accent: "#c4b5fd",
	},
	{
		prefix: "Can one thread carry",
		highlight: "idea to proof",
		suffix: "?",
		accent: "#5eead4",
	},
];

const symbols = ["∫", "√", "∞", "π", "≈", "f(x)", "lim", "dx"] as const;
type ParticleSpec = {
	char: string;
	size: number;
	delay: number;
	launchX: number;
	launchY: number;
	endX: number;
	endY: number;
	arcA: number;
	arcB: number;
	spin: number;
	wobble: number;
	life: number;
	mode: "arc" | "spiral" | "dart" | "float";
};

const PARTICLE_SPECS: ParticleSpec[] = [
	{ char: "∫", size: 34, delay: 0, launchX: -580, launchY: -210, endX: -690, endY: -290, arcA: -20, arcB: 26, spin: -18, wobble: 1.2, life: 42, mode: "arc" },
	{ char: "√", size: 32, delay: 3, launchX: 590, launchY: -220, endX: 720, endY: -300, arcA: 26, arcB: 14, spin: 16, wobble: 1.5, life: 44, mode: "dart" },
	{ char: "∞", size: 28, delay: 5, launchX: -610, launchY: 120, endX: -760, endY: 150, arcA: -22, arcB: -18, spin: -10, wobble: 1.8, life: 45, mode: "float" },
	{ char: "π", size: 30, delay: 7, launchX: 620, launchY: 130, endX: 760, endY: 170, arcA: 24, arcB: -10, spin: 13, wobble: 1.3, life: 46, mode: "arc" },
	{ char: "≈", size: 27, delay: 8, launchX: -230, launchY: -280, endX: -280, endY: -390, arcA: -14, arcB: 10, spin: -9, wobble: 1.1, life: 40, mode: "spiral" },
	{ char: "f(x)", size: 24, delay: 11, launchX: 210, launchY: -285, endX: 260, endY: -400, arcA: 12, arcB: 12, spin: 12, wobble: 1.6, life: 41, mode: "dart" },
	{ char: "lim", size: 24, delay: 13, launchX: -260, launchY: 270, endX: -360, endY: 390, arcA: -12, arcB: 18, spin: -14, wobble: 1.4, life: 40, mode: "float" },
	{ char: "dx", size: 24, delay: 15, launchX: 250, launchY: 270, endX: 350, endY: 390, arcA: 13, arcB: 18, spin: 15, wobble: 1.7, life: 40, mode: "arc" },
	{ char: "∑", size: 30, delay: 6, launchX: -20, launchY: -305, endX: -24, endY: -430, arcA: -16, arcB: 16, spin: -11, wobble: 1.2, life: 43, mode: "spiral" },
	{ char: "tan", size: 23, delay: 12, launchX: 30, launchY: 292, endX: 40, endY: 410, arcA: 16, arcB: 8, spin: 10, wobble: 1.5, life: 39, mode: "dart" },
];

const typedSlice = (text: string, frame: number, start: number, speed: number) => {
	const chars = Math.floor((frame - start) * speed);
	if (chars <= 0) return "";
	return text.slice(0, Math.min(text.length, chars));
};

const windowOpacity = (frame: number, start: number, end: number, ramp = 14) => {
	const fadeIn = interpolate(frame, [start, start + ramp], [0, 1], {
		extrapolateLeft: "clamp",
		extrapolateRight: "clamp",
	});
	const fadeOut = interpolate(frame, [end - ramp, end], [1, 0], {
		extrapolateLeft: "clamp",
		extrapolateRight: "clamp",
	});
	return fadeIn * fadeOut;
};

const MathDust: React.FC<{ energy: number }> = ({ energy }) => {
	const frame = useCurrentFrame();
	return (
		<>
			{symbols.map((char, i) => {
				const xWave = Math.sin((frame + i * 37) / 28) * (8 + energy * 7);
				const yWave = Math.cos((frame + i * 29) / 23) * (8 + energy * 6);
				const spin = Math.sin((frame + i * 11) / 34) * 9;
				return (
					<span
						key={`${char}-${i}`}
						style={{
							position: "absolute",
							left: `${8 + (i % 4) * 24}%`,
							top: `${10 + Math.floor(i / 4) * 62}%`,
							fontFamily: "var(--font-geist-pixel-square)",
							fontSize: 34 + (i % 3) * 10,
							color: i % 2 === 0 ? "#818cf8" : "#22d3ee",
							opacity: 0.08 + energy * 0.06,
							transform: `translate(${xWave}px, ${yWave}px) rotate(${spin}deg)`,
							pointerEvents: "none",
							userSelect: "none",
						}}
					>
						{char}
					</span>
				);
			})}
		</>
	);
};

const PostTypeParticles: React.FC<{
	triggerFrame: number;
	accent: string;
	intensity?: number;
	zone?: "title" | "question";
	centerX?: string;
	centerY?: string;
}> = ({
	triggerFrame,
	accent,
	intensity = 1,
	zone = "title",
	centerX = "50%",
	centerY,
}) => {
	const frame = useCurrentFrame();
	const zoneScale = zone === "question" ? 1.08 : 0.94;
	const anchorY = centerY ?? (zone === "question" ? "52%" : "49%");

	return (
		<AbsoluteFill style={{ pointerEvents: "none" }}>
			{PARTICLE_SPECS.map((spec, i) => {
				const local = frame - (triggerFrame + spec.delay);
				const pop = interpolate(local, [0, 5, spec.life * 0.58, spec.life], [0, 1, 0.84, 0], {
					extrapolateLeft: "clamp",
					extrapolateRight: "clamp",
				});
				const t = interpolate(local, [0, spec.life], [0, 1], {
					extrapolateLeft: "clamp",
					extrapolateRight: "clamp",
				});
				const curveX = Math.sin(t * Math.PI) * spec.arcA;
				const curveY = Math.sin(t * Math.PI) * spec.arcB;
				const spiralX = Math.cos(t * Math.PI * 3.2) * 18 * (1 - t);
				const spiralY = Math.sin(t * Math.PI * 3.2) * 14 * (1 - t);
				const dartKick = interpolate(t, [0, 0.26, 1], [0, 1.1, 1], {
					extrapolateLeft: "clamp",
					extrapolateRight: "clamp",
				});
				const floatLag = interpolate(t, [0, 0.4, 1], [0, 0.35, 1], {
					extrapolateLeft: "clamp",
					extrapolateRight: "clamp",
				});

				let pathX = spec.launchX;
				let pathY = spec.launchY;
				if (spec.mode === "spiral") {
					pathX = spec.launchX + (spec.endX - spec.launchX) * t + spiralX + curveX;
					pathY = spec.launchY + (spec.endY - spec.launchY) * t + spiralY + curveY;
				} else if (spec.mode === "dart") {
					pathX = spec.launchX + (spec.endX - spec.launchX) * t * dartKick + curveX;
					pathY = spec.launchY + (spec.endY - spec.launchY) * t * dartKick + curveY;
				} else if (spec.mode === "float") {
					pathX = spec.launchX + (spec.endX - spec.launchX) * floatLag + curveX;
					pathY = spec.launchY + (spec.endY - spec.launchY) * floatLag + curveY;
				} else {
					pathX = spec.launchX + (spec.endX - spec.launchX) * t + curveX;
					pathY = spec.launchY + (spec.endY - spec.launchY) * t + curveY;
				}
				const wobble = Math.sin((frame + i * 13) / (10 + (i % 4))) * spec.wobble;
				const spin = Math.sin((frame + i * 19) / 16) * spec.spin;
				const scale = 0.7 + pop * 0.55;
				return (
					<span
						key={`${spec.char}-${i}`}
						style={{
							position: "absolute",
							left: centerX,
							top: anchorY,
							fontFamily: "var(--font-geist-pixel-square)",
							fontSize: spec.size,
							color: i % 2 === 0 ? accent : "#ffffff",
							opacity: pop * (0.76 + intensity * 0.1),
							transform: `translate(${pathX * zoneScale + wobble}px, ${pathY * zoneScale - wobble}px) rotate(${spin}deg) scale(${scale})`,
							textShadow: "0 8px 16px rgba(0,0,0,0.35)",
							userSelect: "none",
						}}
					>
						{spec.char}
					</span>
				);
			})}
		</AbsoluteFill>
	);
};

const PunchTitle: React.FC<{
	title: string;
	subtitle?: string;
	accent?: string;
	durationInFrames: number;
}> = ({ title, subtitle, accent = "#818cf8", durationInFrames }) => {
	const frame = useCurrentFrame();
	const zoomHitA = interpolate(frame, [6, 14, 24], [0, 0.08, 0], {
		extrapolateLeft: "clamp",
		extrapolateRight: "clamp",
		easing: Easing.out(Easing.cubic),
	});
	const zoomHitB = interpolate(frame, [36, 44, 54], [0, 0.06, 0], {
		extrapolateLeft: "clamp",
		extrapolateRight: "clamp",
		easing: Easing.out(Easing.cubic),
	});
	const titleScale = 1 + zoomHitA + zoomHitB;
	const titleOpacity = windowOpacity(frame, 0, durationInFrames, 14);
	const titleY = interpolate(frame, [0, 18], [34, 0], {
		extrapolateLeft: "clamp",
		extrapolateRight: "clamp",
		easing: Easing.out(Easing.cubic),
	});

	const typedTitle = typedSlice(title, frame, 6, 1.95);
	const typedSubtitle = subtitle ? typedSlice(subtitle, frame, 28, 1.65) : "";
	const typeDoneFrame = subtitle
		? 28 + Math.ceil(subtitle.length / 1.65)
		: 6 + Math.ceil(title.length / 1.95);

	return (
		<AbsoluteFill
			style={{
				justifyContent: "center",
				alignItems: "center",
				textAlign: "center",
				padding: "0 120px",
				transform: `scale(${titleScale})`,
				opacity: titleOpacity,
			}}
		>
			<div
				style={{
					fontFamily: "var(--font-geist-pixel-square)",
					fontSize: 156,
					lineHeight: 0.9,
					letterSpacing: "-0.04em",
					color: "#f8fafc",
					transform: `translateY(${titleY}px)`,
					textShadow: "0 12px 30px rgba(0,0,0,0.35)",
				}}
			>
				{typedTitle}
			</div>
				{subtitle ? (
					<div
						style={{
							marginTop: 22,
							fontFamily: "var(--font-geist-pixel-square)",
							fontSize: 44,
							fontWeight: 700,
							lineHeight: 1.05,
							letterSpacing: "-0.02em",
							color: accent,
							textShadow: "0 8px 20px rgba(0,0,0,0.3)",
						}}
					>
					{typedSubtitle}
				</div>
			) : null}
			<PostTypeParticles
				triggerFrame={typeDoneFrame + 2}
				accent={accent}
				intensity={0.95}
				zone="title"
				centerY={subtitle ? "49.2%" : "50%"}
			/>
		</AbsoluteFill>
	);
};

const QuestionCard: React.FC<{
	question: QuestionScene;
	durationInFrames: number;
}> = ({ question, durationInFrames }) => {
	const frame = useCurrentFrame();
	const introFrames = 20;
	const outroFrames = 18;
	const typingStart = introFrames - 2;
	const questionSpeed = 1.58;
	const full = `${question.prefix} ${question.highlight}${question.suffix}`;
	const typedChars = Math.max(0, Math.min(full.length, Math.floor((frame - typingStart) * questionSpeed)));
	const prefixWithSpace = `${question.prefix} `;
	const prefixChars = Math.min(prefixWithSpace.length, typedChars);
	const highlightChars = Math.max(0, Math.min(question.highlight.length, typedChars - prefixWithSpace.length));
	const suffixChars = Math.max(0, Math.min(question.suffix.length, typedChars - prefixWithSpace.length - question.highlight.length));

	const sceneIn = interpolate(frame, [0, introFrames], [0, 1], {
		extrapolateLeft: "clamp",
		extrapolateRight: "clamp",
		easing: Easing.out(Easing.cubic),
	});
	const sceneOut = interpolate(frame, [durationInFrames - outroFrames, durationInFrames], [1, 0], {
		extrapolateLeft: "clamp",
		extrapolateRight: "clamp",
		easing: Easing.in(Easing.cubic),
	});
	const sceneOpacity = sceneIn * sceneOut;
	const y = interpolate(frame, [0, introFrames, durationInFrames - outroFrames, durationInFrames], [26, 0, 0, -18], {
		extrapolateLeft: "clamp",
		extrapolateRight: "clamp",
		easing: Easing.inOut(Easing.cubic),
	});
	const sceneScale = interpolate(frame, [0, introFrames, durationInFrames - outroFrames, durationInFrames], [0.982, 1, 1, 1.018], {
		extrapolateLeft: "clamp",
		extrapolateRight: "clamp",
		easing: Easing.inOut(Easing.cubic),
	});
	const sceneBlur = interpolate(frame, [0, 15, durationInFrames - 14, durationInFrames], [14, 0, 0, 10], {
		extrapolateLeft: "clamp",
		extrapolateRight: "clamp",
		easing: Easing.inOut(Easing.cubic),
	});
	const veilOpacity = interpolate(frame, [0, introFrames, durationInFrames - outroFrames, durationInFrames], [0.34, 0.12, 0.14, 0.3], {
		extrapolateLeft: "clamp",
		extrapolateRight: "clamp",
		easing: Easing.inOut(Easing.cubic),
	});
	const questionTypedEnd =
		typingStart +
		Math.ceil((prefixWithSpace.length + question.highlight.length + question.suffix.length) / questionSpeed);
	const highlightTypedEnd =
		typingStart + Math.ceil((prefixWithSpace.length + question.highlight.length) / questionSpeed);
	const underlineProgressRaw = interpolate(
		frame,
		[highlightTypedEnd + 5, highlightTypedEnd + 34],
		[0, 1],
		{
			extrapolateLeft: "clamp",
			extrapolateRight: "clamp",
			easing: Easing.out(Easing.cubic),
		},
	);
	const underlineLagRaw = interpolate(
		frame,
		[highlightTypedEnd + 10, highlightTypedEnd + 40],
		[0, 1],
		{
			extrapolateLeft: "clamp",
			extrapolateRight: "clamp",
			easing: Easing.out(Easing.quad),
		},
	);
	const segmentCount = 18;
	const segmentHeights = [7, 9, 8, 10, 7, 8, 9, 7, 10, 8, 7, 9, 8, 10, 7, 8, 9, 7] as const;

	return (
		<AbsoluteFill style={{ background: "#020617", overflow: "hidden" }}>
			<MathDust energy={1.35} />
			<div
				style={{
					position: "absolute",
					inset: 0,
					background:
						"radial-gradient(circle at 25% 18%, rgba(79,70,229,0.18) 0%, rgba(2,6,23,0) 56%), radial-gradient(circle at 82% 76%, rgba(6,182,212,0.16) 0%, rgba(2,6,23,0) 58%)",
				}}
			/>
			<div
				style={{
					position: "absolute",
					inset: 0,
					background: "linear-gradient(180deg, rgba(2,6,23,0.6) 0%, rgba(2,6,23,0.12) 44%, rgba(2,6,23,0.64) 100%)",
					opacity: veilOpacity,
				}}
			/>
			<AbsoluteFill
				style={{
					alignItems: "center",
					justifyContent: "center",
					padding: "0 120px",
					opacity: sceneOpacity,
					transform: `translateY(${y}px) scale(${sceneScale})`,
					filter: `blur(${sceneBlur}px)`,
				}}
			>
				<div
					style={{
						maxWidth: 1520,
						textAlign: "center",
						fontFamily: "var(--font-geist-pixel-square)",
						fontSize: 104,
						lineHeight: 0.96,
						letterSpacing: "-0.035em",
						color: "#f8fafc",
						textShadow: "0 12px 30px rgba(0,0,0,0.4)",
					}}
				>
					{prefixWithSpace.slice(0, prefixChars)}
						<span
							style={{
								position: "relative",
								color: question.accent,
								display: "inline-block",
						}}
						>
							{question.highlight.slice(0, highlightChars)}
							<span
								style={{
									position: "absolute",
									left: 0,
									bottom: -14,
									width: "100%",
									display: "grid",
									gridTemplateColumns: `repeat(${segmentCount}, minmax(0, 1fr))`,
									columnGap: 2,
									transform: "rotate(-0.8deg)",
									pointerEvents: "none",
								}}
							>
								{segmentHeights.map((h, i) => {
									const segOn = interpolate(
										underlineProgressRaw,
										[i / segmentCount, (i + 0.88) / segmentCount],
										[0, 1],
										{
											extrapolateLeft: "clamp",
											extrapolateRight: "clamp",
										},
									);
									const segLag = interpolate(
										underlineLagRaw,
										[i / segmentCount, (i + 0.88) / segmentCount],
										[0, 1],
										{
											extrapolateLeft: "clamp",
											extrapolateRight: "clamp",
										},
									);
									return (
										<span
											key={`seg-${i}`}
											style={{
												position: "relative",
												height: h,
												background: question.accent,
												opacity: segOn * 0.86,
												transform: `translateY(${i % 3 === 0 ? 1 : 0}px)`,
											}}
										>
											<span
												style={{
													position: "absolute",
													left: 0,
													top: 0,
													width: "100%",
													height: Math.max(2, h - 5),
													background: "#ffffff",
													opacity: segLag * 0.22,
												}}
											/>
										</span>
									);
								})}
							</span>
						</span>
						{question.suffix.slice(0, suffixChars)}
					</div>
				</AbsoluteFill>
				<PostTypeParticles
					triggerFrame={questionTypedEnd + 3}
					accent={question.accent}
					intensity={1.2}
					zone="question"
					centerY="51.3%"
				/>
			</AbsoluteFill>
		);
	};

const ClipAct: React.FC<{
	clip: ClipSpec;
	lines: OverlayLine[];
	accent: string;
	energy: number;
}> = ({ clip, lines, accent, energy }) => {
	const frame = useCurrentFrame();
	const [videoFailed, setVideoFailed] = React.useState(false);

	React.useEffect(() => {
		setVideoFailed(false);
	}, [clip.src]);

	const zoomHitA = interpolate(frame, [22, 32, 44], [0, 0.09 * energy, 0], {
		extrapolateLeft: "clamp",
		extrapolateRight: "clamp",
		easing: Easing.out(Easing.cubic),
	});
	const zoomHitB = interpolate(frame, [80, 90, 102], [0, 0.11 * energy, 0], {
		extrapolateLeft: "clamp",
		extrapolateRight: "clamp",
		easing: Easing.out(Easing.cubic),
	});
	const zoomHitC = interpolate(frame, [138, 148, 162], [0, 0.12 * energy, 0], {
		extrapolateLeft: "clamp",
		extrapolateRight: "clamp",
		easing: Easing.out(Easing.cubic),
	});
	const macroPunch = interpolate(frame, [0, 90, 186], [0, 0.03 * energy, 0.07 * energy], {
		extrapolateLeft: "clamp",
		extrapolateRight: "clamp",
		easing: Easing.inOut(Easing.cubic),
	});

	const driftX = Math.sin(frame / 40) * (10 + energy * 8);
	const driftY = Math.cos(frame / 52) * (8 + energy * 6);
	const zoom =
		1.06 +
		energy * 0.06 +
		zoomHitA +
		zoomHitB +
		zoomHitC +
		macroPunch -
		interpolate(frame, [0, 170], [0, 0.03], {
			extrapolateLeft: "clamp",
			extrapolateRight: "clamp",
		});
	const videoSrc = clip.src;

	return (
		<AbsoluteFill style={{ overflow: "hidden", background: "#020617" }}>
			{videoSrc && !videoFailed ? (
				<OffthreadVideo
					src={staticFile(videoSrc)}
					muted
					onError={(err) => {
						console.warn(`[VibrantMinimalDemo] Video failed: ${videoSrc}`, err);
						setVideoFailed(true);
					}}
					style={{
						width: "100%",
						height: "100%",
						objectFit: "cover",
						transform: `translate(${driftX}px, ${driftY}px) scale(${zoom})`,
					}}
				/>
			) : (
				<AbsoluteFill
					style={{
						background:
							"radial-gradient(circle at 22% 18%, rgba(79,70,229,0.4) 0%, rgba(2,6,23,1) 62%), radial-gradient(circle at 82% 76%, rgba(6,182,212,0.34) 0%, rgba(2,6,23,1) 58%)",
					}}
				/>
			)}

			<AbsoluteFill
				style={{
					background:
						"linear-gradient(180deg, rgba(2,6,23,0.46) 0%, rgba(2,6,23,0.18) 42%, rgba(2,6,23,0.58) 100%)",
				}}
			/>

			<MathDust energy={energy} />

			<div
				style={{
					position: "absolute",
					top: 34,
					left: 34,
					padding: "8px 14px",
					borderRadius: 999,
					background: "rgba(15,23,42,0.52)",
					border: "1px solid rgba(148,163,184,0.35)",
					color: "#e2e8f0",
					fontFamily: "var(--font-geist-sans)",
					fontWeight: 700,
					fontSize: 19,
				}}
			>
				{clip.label}
			</div>

			<div style={{ position: "absolute", left: 68, right: 68, bottom: 80 }}>
				{lines.map((line, idx) => {
					const opacity = windowOpacity(frame, line.from, line.from + 72, 14);
					const y = interpolate(frame, [line.from, line.from + 16], [18, 0], {
						extrapolateLeft: "clamp",
						extrapolateRight: "clamp",
						easing: Easing.out(Easing.cubic),
					});
					const typed = typedSlice(line.text, frame, line.from + 6, 1.7);
					if (!typed) return null;
					return (
						<div
							key={`${line.text}-${idx}`}
							style={{
								marginTop: idx === 0 ? 0 : 10,
								opacity,
								transform: `translateY(${y}px) scale(${1 + zoomHitA * 0.4 + zoomHitB * 0.35})`,
								fontFamily: "var(--font-geist-pixel-square)",
								fontSize: idx === 0 ? 76 : 56,
								lineHeight: 1,
								letterSpacing: "-0.03em",
								color: idx === 0 ? "#ffffff" : accent,
								textShadow: "0 10px 24px rgba(0,0,0,0.5)",
							}}
						>
							{typed}
						</div>
					);
				})}
			</div>
		</AbsoluteFill>
	);
};

export const VibrantMinimalDemo: React.FC<{
	audioSrc?: string;
	clips?: ClipSpec[];
}> = ({ audioSrc = "/music.mp3", clips = fallbackClips }) => {
	const frame = useCurrentFrame();
	const clip1 = clips[0] ?? fallbackClips[0];
	const clip2 = clips[1] ?? fallbackClips[1];
	const clip3 = clips[2] ?? fallbackClips[2];

	const bgPulse = 0.08 + Math.sin(frame / 54) * 0.025;

	return (
		<>
			<Audio
				src={staticFile(audioSrc)}
				playbackRate={1.08}
				volume={(f) =>
					interpolate(
						f,
						[0, 22, VIBRANT_MINIMAL_DURATION * 0.35, VIBRANT_MINIMAL_DURATION * 0.72, VIBRANT_MINIMAL_DURATION - 14, VIBRANT_MINIMAL_DURATION],
						[0, 0.1, 0.18, 0.28, 0.32, 0],
						{
							extrapolateLeft: "clamp",
							extrapolateRight: "clamp",
							easing: Easing.inOut(Easing.cubic),
						},
					)
				}
			/>

			<AbsoluteFill style={{ background: `rgba(2,6,23,${0.96 + bgPulse})` }}>
				<Series>
					<Series.Sequence durationInFrames={ACTS.opener} premountFor={18}>
						<PunchTitle
							title="ProofMesh"
							subtitle="Collaborative math proving"
							accent="#22d3ee"
							durationInFrames={ACTS.opener}
						/>
					</Series.Sequence>

					<Series.Sequence durationInFrames={ACTS.tension} premountFor={18}>
						<PunchTitle
							title="Research is fast."
							subtitle="Verification should be too."
							accent="#a5b4fc"
							durationInFrames={ACTS.tension}
						/>
					</Series.Sequence>

					<Series.Sequence durationInFrames={ACTS.canvas} premountFor={18}>
						<ClipAct clip={clip1} lines={clipText.canvas} accent="#67e8f9" energy={0.85} />
					</Series.Sequence>

					<Series.Sequence durationInFrames={ACTS.questionA} premountFor={18}>
						<QuestionCard question={questionScenes[0]} durationInFrames={ACTS.questionA} />
					</Series.Sequence>

					<Series.Sequence durationInFrames={ACTS.verify} premountFor={18}>
						<ClipAct clip={clip2} lines={clipText.verify} accent="#c4b5fd" energy={1.05} />
					</Series.Sequence>

					<Series.Sequence durationInFrames={ACTS.questionB} premountFor={18}>
						<QuestionCard question={questionScenes[1]} durationInFrames={ACTS.questionB} />
					</Series.Sequence>

					<Series.Sequence durationInFrames={ACTS.collab} premountFor={18}>
						<ClipAct clip={clip3} lines={clipText.collab} accent="#5eead4" energy={1.25} />
					</Series.Sequence>

					<Series.Sequence durationInFrames={ACTS.questionC} premountFor={18}>
						<QuestionCard question={questionScenes[2]} durationInFrames={ACTS.questionC} />
					</Series.Sequence>

					<Series.Sequence durationInFrames={ACTS.climax} premountFor={18}>
						<PunchTitle
							title="Build live."
							subtitle="From idea to machine-checked proof."
							accent="#67e8f9"
							durationInFrames={ACTS.climax}
						/>
					</Series.Sequence>

					<Series.Sequence durationInFrames={ACTS.outro} premountFor={18}>
						<PunchTitle
							title="ProofMesh"
							subtitle="Start proving"
							accent="#a5b4fc"
							durationInFrames={ACTS.outro}
						/>
					</Series.Sequence>
				</Series>
			</AbsoluteFill>
		</>
	);
};
