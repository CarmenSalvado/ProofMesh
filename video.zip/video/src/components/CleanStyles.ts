export const CLEAN_STYLES = {
  colors: {
    white: "#FFFFFF",
    black: "#000000",
    gray: {
      100: "#F3F4F6",
      200: "#E5E7EB",
      800: "#1F2937",
    },
  },
  fonts: {
    geistPixel: "var(--font-geist-pixel-square)",
    sans: "var(--font-geist-sans)",
  },
} as const;