import React from "react";
import { useCurrentFrame, useVideoConfig, interpolate, spring } from "remotion";
import { COLORS, FONTS } from "./ProofMeshStyles";
import { FileText } from "./Icons";

interface MathFormulaProps {
  formula: string;
  startFrame?: number;
  x?: number;
  y?: number;
  scale?: number;
  color?: string;
}

export const MathFormula: React.FC<MathFormulaProps> = ({
  formula,
  startFrame = 0,
  x = 960,
  y = 540,
  scale = 1,
  color = COLORS.textSecondary,
}) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  const progress = spring({
    frame: frame - startFrame,
    fps,
    config: { damping: 200 },
  });

  const opacity = interpolate(progress, [0, 1], [0, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });

  const scaleValue = interpolate(progress, [0, 1], [0.8, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });

  return (
    <div
      style={{
        position: "absolute",
        left: x,
        top: y,
        transform: `translate(-50%, -50%) scale(${scaleValue * scale})`,
        opacity,
        fontFamily: FONTS.math,
        fontSize: "42px",
        color,
        fontStyle: "italic",
        letterSpacing: "0.02em",
      }}
    >
      {formula}
    </div>
  );
};

export const LaTeXEditor: React.FC<{ 
  code: string; 
  startFrame?: number;
  title?: string;
}> = ({ code, startFrame = 0, title = "lemma.md" }) => {
  const frame = useCurrentFrame();

  const lines = code.split("\n");
  const charsPerFrame = 2;
  const totalChars = frame - startFrame * charsPerFrame;

  const displayedLines = lines.map((line, lineIdx) => {
    const lineStart = lineIdx * 40;
    if (totalChars < lineStart) return "";
    const lineChars = Math.min(line.length, totalChars - lineStart);
    return line.substring(0, lineChars);
  });

  const cursorVisible = Math.floor(frame / 8) % 2 === 0;

  return (
    <div
      style={{
        backgroundColor: COLORS.bgSecondary,
        border: `1px solid ${COLORS.borderPrimary}`,
        borderRadius: "12px",
        overflow: "hidden",
        boxShadow: "0 25px 50px -12px rgba(0, 0, 0, 0.6)",
        minWidth: "520px",
      }}
    >
      {/* Window header */}
      <div
        style={{
          backgroundColor: COLORS.bgTertiary,
          borderBottom: `1px solid ${COLORS.borderPrimary}`,
          padding: "12px 16px",
          display: "flex",
          alignItems: "center",
          gap: "8px",
        }}
      >
        <div
          style={{ width: 10, height: 10, borderRadius: "50%", backgroundColor: "#ff5f57" }}
        />
        <div
          style={{ width: 10, height: 10, borderRadius: "50%", backgroundColor: "#febc2e" }}
        />
        <div
          style={{ width: 10, height: 10, borderRadius: "50%", backgroundColor: "#28c840" }}
        />
        <div style={{ marginLeft: "8px", display: "flex", alignItems: "center", gap: "6px" }}>
          <FileText size={12} color={COLORS.textMuted} />
          <span
            style={{
              fontSize: "12px",
              color: COLORS.textMuted,
              fontFamily: FONTS.sans,
            }}
          >
            {title}
          </span>
        </div>
      </div>

      {/* Editor content */}
      <div
        style={{
          padding: "20px 24px",
          fontFamily: FONTS.mono,
          fontSize: "15px",
          lineHeight: "1.7",
          color: COLORS.textSecondary,
          backgroundColor: COLORS.bgSecondary,
        }}
      >
        <pre style={{ margin: 0 }}>
          {displayedLines.map((line, i) => (
            <div key={i} style={{ display: "flex" }}>
              <span style={{ color: COLORS.textFaint, width: "32px", userSelect: "none" }}>
                {(i + 1).toString().padStart(2, "0")}
              </span>
              <span
                style={{
                  color: line.startsWith("##")
                    ? COLORS.indigo[500]
                    : line.startsWith("$")
                    ? COLORS.emerald[500]
                    : line.startsWith("\\")
                    ? COLORS.amber[500]
                    : COLORS.textSecondary,
                }}
              >
                {line}
                {i === displayedLines.length - 1 && cursorVisible && (
                  <span style={{ color: COLORS.emerald[500] }}>|</span>
                )}
              </span>
            </div>
          ))}
        </pre>
      </div>
    </div>
  );
};
