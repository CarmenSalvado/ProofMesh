import React from "react";
import { useCurrentFrame, useVideoConfig, spring } from "remotion";
import { COLORS, FONTS } from "./ProofMeshStyles";
import { Star, GitFork, Check, Search, Bot } from "./Icons";

interface Activity {
  id: number;
  user: string;
  avatar: string;
  action: string;
  target: string;
  time: string;
  likes: number;
  icon: "star" | "fork" | "check" | "search" | "bot";
  iconColor: string;
}

const ACTIVITIES: Activity[] = [
  { id: 1, user: "Alice", avatar: "A", action: "proved", target: "Theorem A", time: "2m ago", likes: 12, icon: "check", iconColor: COLORS.emerald[500] },
  { id: 2, user: "Bob", avatar: "B", action: "forked", target: "Workspace #42", time: "5m ago", likes: 8, icon: "fork", iconColor: COLORS.indigo[500] },
  { id: 3, user: "Carol", avatar: "C", action: "starred", target: "Lemma 7.3", time: "12m ago", likes: 24, icon: "star", iconColor: COLORS.amber[500] },
  { id: 4, user: "David", avatar: "D", action: "verified", target: "Proof of X", time: "15m ago", likes: 31, icon: "check", iconColor: COLORS.emerald[500] },
  { id: 5, user: "Eve", avatar: "E", action: "explored", target: "Branch #12", time: "20m ago", likes: 5, icon: "bot", iconColor: COLORS.indigo[500] },
];

const IconComponent: React.FC<{ type: string; size?: number; color?: string }> = ({ type, size = 14, color }) => {
  switch (type) {
    case "star": return <Star size={size} color={color} />;
    case "fork": return <GitFork size={size} color={color} />;
    case "check": return <Check size={size} color={color} />;
    case "search": return <Search size={size} color={color} />;
    case "bot": return <Bot size={size} color={color} />;
    default: return <Star size={size} color={color} />;
  }
};

export const SocialFeed: React.FC<{ startFrame?: number }> = ({
  startFrame = 0,
}) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  return (
    <div
      style={{
        position: "absolute",
        left: 960,
        top: 540,
        transform: "translate(-50%, -50%)",
        width: "480px",
        display: "flex",
        flexDirection: "column",
        gap: "10px",
      }}
    >
      {ACTIVITIES.map((activity, i) => {
        const activityProgress = spring({
          frame: frame - startFrame - i * 12,
          fps,
          config: { damping: 200 },
        });

        return (
          <div
            key={activity.id}
            style={{
              transform: `translateX(${(1 - activityProgress) * 60}px)`,
              opacity: activityProgress,
              backgroundColor: COLORS.bgSecondary,
              border: `1px solid ${COLORS.borderPrimary}`,
              borderRadius: "12px",
              padding: "14px 16px",
              display: "flex",
              alignItems: "center",
              gap: "12px",
              boxShadow: "0 1px 2px rgba(0, 0, 0, 0.3)",
            }}
          >
            {/* Avatar */}
            <div
              style={{
                width: 36,
                height: 36,
                borderRadius: "50%",
                background: `linear-gradient(135deg, ${COLORS.indigo[500]}, ${COLORS.emerald[500]})`,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                fontSize: "14px",
                fontWeight: 700,
                color: "#ffffff",
                fontFamily: FONTS.sans,
              }}
            >
              {activity.avatar}
            </div>
            
            <div style={{ flex: 1 }}>
              <div style={{ color: COLORS.textPrimary, fontWeight: 500, fontSize: "13px", fontFamily: FONTS.sans }}>
                {activity.user}{" "}
                <span style={{ color: COLORS.textMuted, fontWeight: 400 }}>
                  {activity.action}
                </span>{" "}
                <span style={{ color: COLORS.indigo[500] }}>{activity.target}</span>
              </div>
              <div style={{ color: COLORS.textFaint, fontSize: "11px", marginTop: "2px", fontFamily: FONTS.sans }}>
                {activity.time}
              </div>
            </div>
            
            {/* Likes */}
            <div
              style={{
                display: "flex",
                alignItems: "center",
                gap: "4px",
                color: COLORS.amber[500],
                fontSize: "12px",
              }}
            >
              <IconComponent type={activity.icon} size={14} color={activity.iconColor} />
              <span style={{ fontWeight: 600, fontFamily: FONTS.sans }}>{activity.likes}</span>
            </div>
          </div>
        );
      })}
    </div>
  );
};

export const UserProfile: React.FC<{
  name: string;
  role: string;
  contributions: number;
  startFrame?: number;
  x?: number;
  y?: number;
}> = ({ name, role, contributions, startFrame = 0, x = 0, y = 0 }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  const progress = spring({
    frame: frame - startFrame,
    fps,
    config: { damping: 200 },
  });

  return (
    <div
      style={{
        position: "absolute",
        left: x,
        top: y,
        transform: `translate(-50%, -50%) scale(${progress})`,
        opacity: progress,
        backgroundColor: COLORS.bgSecondary,
        border: `1px solid ${COLORS.borderPrimary}`,
        borderRadius: "16px",
        padding: "24px",
        width: "180px",
        textAlign: "center",
        boxShadow: "0 8px 30px rgba(0, 0, 0, 0.4)",
      }}
    >
      <div
        style={{
          width: "56px",
          height: "56px",
          borderRadius: "50%",
          background: `linear-gradient(135deg, ${COLORS.indigo[500]}, ${COLORS.emerald[500]})`,
          margin: "0 auto 12px",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          fontSize: "24px",
          fontWeight: 700,
          color: "#ffffff",
          fontFamily: FONTS.sans,
        }}
      >
        {name[0]}
      </div>
      <div style={{ color: COLORS.textPrimary, fontWeight: 600, fontSize: "16px", fontFamily: FONTS.sans }}>
        {name}
      </div>
      <div style={{ color: COLORS.textMuted, fontSize: "12px", marginTop: "4px", fontFamily: FONTS.sans }}>
        {role}
      </div>
      <div
        style={{
          marginTop: "16px",
          paddingTop: "16px",
          borderTop: `1px solid ${COLORS.borderPrimary}`,
        }}
      >
        <div style={{ color: COLORS.textFaint, fontSize: "10px", textTransform: "uppercase", letterSpacing: "0.1em", fontFamily: FONTS.sans }}>
          Contributions
        </div>
        <div style={{ color: COLORS.emerald[500], fontWeight: 700, fontSize: "22px", marginTop: "4px", fontFamily: FONTS.sans }}>
          {contributions}
        </div>
      </div>
    </div>
  );
};
