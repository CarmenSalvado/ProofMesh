import React from "react";
import {
	AbsoluteFill,
	Easing,
	interpolate,
	spring,
	useCurrentFrame,
	useVideoConfig,
} from "remotion";

export type VibrantSymbolSpec = {
	char: string;
	top?: number;
	right?: number;
	bottom?: number;
	left?: number;
	size: number;
	rotate: number;
	color?: string;
	opacity?: number;
	driftX?: number;
	driftY?: number;
	wobble?: number;
	delay?: number;
};

const DEFAULT_SYMBOLS: VibrantSymbolSpec[] = [
	{ char: "∫", top: 96, left: 108, size: 88, rotate: -10, driftY: 3, delay: 0 },
	{ char: "√", top: 124, right: 138, size: 74, rotate: 8, driftY: 2, delay: 6 },
	{ char: "∞", bottom: 112, left: 150, size: 66, rotate: -7, driftX: 2, delay: 12 },
	{ char: "π", bottom: 102, right: 180, size: 68, rotate: 9, driftX: 1, delay: 18 },
];

export const VibrantMathSlide: React.FC<{
	title: string;
	sentence: string;
	symbols?: VibrantSymbolSpec[];
	badgeText?: string;
	kicker?: string;
	contentOnly?: boolean;
}> = ({
	title,
	sentence,
	symbols = DEFAULT_SYMBOLS,
	badgeText,
	kicker,
	contentOnly = false,
}) => {
	const frame = useCurrentFrame();
	const { fps } = useVideoConfig();

	const titleStart = 6;
	const subtitleStart = 24 + title.length / 2.2;

	const titleChars = Math.min(
		title.length,
		Math.floor(Math.max(0, frame - titleStart) * 2.6),
	);
	const subtitleChars = Math.min(
		sentence.length,
		Math.floor(Math.max(0, frame - subtitleStart) * 2.4),
	);

	const sceneOpacity = interpolate(frame, [0, 12], [0, 1], {
		extrapolateRight: "clamp",
	});
	const sceneLift = interpolate(frame, [0, 24], [34, 0], {
		extrapolateRight: "clamp",
		easing: Easing.out(Easing.cubic),
	});
	const sceneScale = spring({
		frame,
		fps,
		config: {
			damping: 180,
			stiffness: 110,
			mass: 0.75,
		},
		durationInFrames: 34,
	});
	const bgShiftA = Math.sin(frame / 54) * 56;
	const bgShiftB = Math.cos(frame / 44) * 44;
	const sweepX = interpolate(frame, [0, 90], [-1400, 2200], {
		extrapolateLeft: "clamp",
		extrapolateRight: "clamp",
	});
	const sweepOpacity = interpolate(frame, [8, 28], [0, 0.9], {
		extrapolateLeft: "clamp",
		extrapolateRight: "clamp",
	});
	const titleY = interpolate(frame, [8, 30], [24, 0], {
		extrapolateLeft: "clamp",
		extrapolateRight: "clamp",
		easing: Easing.out(Easing.cubic),
	});
	const sentenceY = interpolate(frame, [24, 44], [18, 0], {
		extrapolateLeft: "clamp",
		extrapolateRight: "clamp",
		easing: Easing.out(Easing.cubic),
	});
	const sentenceOpacity = interpolate(frame, [20, 44], [0.25, 1], {
		extrapolateLeft: "clamp",
		extrapolateRight: "clamp",
	});

	return (
		<AbsoluteFill
			style={{
				background: contentOnly ? "transparent" : "#ffffff",
				fontFamily: "var(--font-geist-pixel-square)",
				color: "#0a0a0a",
				overflow: "hidden",
			}}
		>
			{contentOnly ? null : (
				<>
					<div
						style={{
							position: "absolute",
							inset: 0,
							backgroundImage:
								"radial-gradient(circle, rgba(100,116,139,0.12) 1px, transparent 1px)",
							backgroundSize: "32px 32px",
							opacity: 0.2,
						}}
					/>

					<div
						style={{
							position: "absolute",
							width: 760,
							height: 760,
							left: -180,
							top: -180,
							borderRadius: "50%",
							background:
								"radial-gradient(circle, rgba(79,70,229,0.18) 0%, rgba(255,255,255,0) 72%)",
							filter: "blur(60px)",
							transform: `translate(${bgShiftA}px, ${bgShiftB * 0.3}px)`,
						}}
					/>

					<div
						style={{
							position: "absolute",
							width: 660,
							height: 660,
							right: -160,
							bottom: -220,
							borderRadius: "50%",
							background:
								"radial-gradient(circle, rgba(6,182,212,0.18) 0%, rgba(255,255,255,0) 74%)",
							filter: "blur(56px)",
							transform: `translate(${bgShiftB * 0.4}px, ${bgShiftA * 0.35}px)`,
						}}
					/>
				</>
			)}

			<div
				style={{
					position: "absolute",
					top: -220,
					left: sweepX,
					width: 520,
					height: 1600,
					opacity: sweepOpacity,
					transform: "rotate(18deg)",
					background:
						"linear-gradient(90deg, rgba(255,255,255,0) 0%, rgba(99,102,241,0.12) 45%, rgba(6,182,212,0.1) 55%, rgba(255,255,255,0) 100%)",
					filter: "blur(14px)",
				}}
			/>

			{symbols.map((symbol, i) => {
				const localFrame = Math.max(0, frame - (symbol.delay ?? i * 4));
				const pulse = interpolate(
					localFrame,
					[0, 24],
					[0.58, 1],
					{ extrapolateRight: "clamp" },
				);
				const floatX = Math.cos((frame + i * 11) / 20) * (symbol.driftX ?? 0);
				const floatY = Math.sin((frame + i * 13) / 18) * (symbol.driftY ?? 0);
				const wobble = Math.sin((frame + i * 17) / 26) * (symbol.wobble ?? 1.5);
				const reveal = interpolate(localFrame, [0, 16], [0, 1], {
					extrapolateRight: "clamp",
				});
				return (
					<span
						key={`${symbol.char}-${i}`}
						style={{
							position: "absolute",
							top: symbol.top,
							right: symbol.right,
							bottom: symbol.bottom,
							left: symbol.left,
							fontFamily: "var(--font-geist-pixel-square)",
							fontSize: symbol.size,
							color: symbol.color ?? "#4f46e5",
							opacity: (symbol.opacity ?? 0.16) * reveal,
							transform: `translate(${floatX}px, ${floatY + (1 - reveal) * 20}px) rotate(${symbol.rotate + wobble}deg) scale(${pulse})`,
							lineHeight: 1,
							userSelect: "none",
						}}
					>
						{symbol.char}
					</span>
				);
			})}

			<div
				style={{
					position: "absolute",
					inset: 0,
					display: "flex",
					alignItems: "center",
					justifyContent: "center",
					padding: "0 140px",
				}}
			>
				<div
					style={{
						maxWidth: 1580,
						width: "100%",
						opacity: sceneOpacity,
						transform: `translateY(${sceneLift}px) scale(${0.985 + sceneScale * 0.015})`,
						display: "flex",
						flexDirection: "column",
						alignItems: "center",
						textAlign: "center",
					}}
				>
					{kicker ? (
						<div
							style={{
								fontFamily: "var(--font-geist-sans)",
								fontSize: 23,
								fontWeight: 700,
								color: "#4f46e5",
								textTransform: "uppercase",
								letterSpacing: "0.08em",
								opacity: interpolate(frame, [8, 22], [0, 1], {
									extrapolateLeft: "clamp",
									extrapolateRight: "clamp",
								}),
								transform: `translateY(${interpolate(frame, [8, 22], [8, 0], {
									extrapolateLeft: "clamp",
									extrapolateRight: "clamp",
								})}px)`,
								marginBottom: 14,
							}}
						>
							{kicker}
						</div>
					) : null}

					<div
						style={{
							fontFamily: "var(--font-geist-pixel-square)",
							fontSize: 188,
							lineHeight: 0.9,
							letterSpacing: "-0.04em",
							fontWeight: 700,
							minHeight: 182,
							transform: `translateY(${titleY}px)`,
							textShadow: "0 12px 28px rgba(15,23,42,0.08)",
						}}
					>
						{title.slice(0, titleChars)}
					</div>

					<div
						style={{
							marginTop: 22,
							fontSize: 64,
							lineHeight: 1.15,
							fontWeight: 600,
							color: "#111827",
							minHeight: 150,
							fontFamily: "var(--font-geist-pixel-square)",
							opacity: sentenceOpacity,
							transform: `translateY(${sentenceY}px)`,
							maxWidth: 1320,
						}}
					>
						{sentence.slice(0, subtitleChars)}
					</div>

					{badgeText ? (
						<div
							style={{
								marginTop: 26,
								display: "inline-flex",
								alignItems: "center",
								padding: "8px 16px",
								borderRadius: 999,
								background: "rgba(79, 70, 229, 0.08)",
								border: "1px solid rgba(79, 70, 229, 0.2)",
								color: "#3730a3",
								fontSize: 21,
								fontWeight: 700,
								fontFamily: "var(--font-geist-pixel-square)",
							}}
						>
							{badgeText}
						</div>
					) : null}
				</div>
			</div>
		</AbsoluteFill>
	);
};
