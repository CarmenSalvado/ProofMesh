import React from "react";
import { useCurrentFrame, interpolate, Easing, useVideoConfig } from "remotion";
import { COLORS, FONTS } from "./ProofMeshStyles";

interface AnimatedTextProps {
  text: string;
  startFrame?: number;
  duration?: number;
  className?: string;
  style?: React.CSSProperties;
  type?: "typewriter" | "fade" | "slideUp" | "scale";
  color?: string;
  fontSize?: string;
  fontWeight?: number;
}

export const AnimatedText: React.FC<AnimatedTextProps> = ({
  text,
  startFrame = 0,
  duration = 60,
  className = "",
  style = {},
  type = "fade",
  color = COLORS.textPrimary,
  fontSize = "24px",
  fontWeight = 400,
}) => {
  const frame = useCurrentFrame();

  const progress = interpolate(
    frame,
    [startFrame, startFrame + duration],
    [0, 1],
    {
      extrapolateLeft: "clamp",
      extrapolateRight: "clamp",
      easing: Easing.out(Easing.quad),
    }
  );

  const baseStyle: React.CSSProperties = {
    fontFamily: FONTS.sans,
    color,
    fontSize,
    fontWeight,
    ...style,
  };

  if (type === "typewriter") {
    const charCount = Math.floor(progress * text.length);
    const displayText = text.slice(0, charCount);
    const showCursor = frame < startFrame + duration + 15;

    return (
      <span className={className} style={baseStyle}>
        {displayText}
        {showCursor && (
          <span
            style={{
              color: COLORS.emerald[500],
              opacity: Math.floor(frame / 5) % 2 === 0 ? 1 : 0,
            }}
          >
            │
          </span>
        )}
      </span>
    );
  }

  if (type === "fade") {
    return (
      <span className={className} style={{ ...baseStyle, opacity: progress }}>
        {text}
      </span>
    );
  }

  if (type === "slideUp") {
    const translateY = interpolate(progress, [0, 1], [30, 0], {
      extrapolateLeft: "clamp",
      extrapolateRight: "clamp",
    });

    return (
      <span
        className={className}
        style={{
          ...baseStyle,
          opacity: progress,
          transform: `translateY(${translateY}px)`,
          display: "inline-block",
        }}
      >
        {text}
      </span>
    );
  }

  if (type === "scale") {
    const scale = interpolate(progress, [0, 1], [0.9, 1], {
      extrapolateLeft: "clamp",
      extrapolateRight: "clamp",
    });

    return (
      <span
        className={className}
        style={{
          ...baseStyle,
          opacity: progress,
          transform: `scale(${scale})`,
          display: "inline-block",
        }}
      >
        {text}
      </span>
    );
  }

  return <span className={className} style={baseStyle}>{text}</span>;
};

// NEW: Fast Typewriter component for slide text
interface TypewriterTextProps {
  text: string;
  startFrame?: number;
  charsPerFrame?: number;
  cursorColor?: string;
  className?: string;
  style?: React.CSSProperties;
  onComplete?: () => void;
}

export const TypewriterText: React.FC<TypewriterTextProps> = ({
  text,
  startFrame = 0,
  charsPerFrame = 1.5,
  cursorColor = "#10B981",
  className = "",
  style = {},
}) => {
  const frame = useCurrentFrame();
  const elapsedFrames = Math.max(0, frame - startFrame);
  
  // Calculate how many characters to show
  const charCount = Math.min(
    text.length,
    Math.floor(elapsedFrames * charsPerFrame)
  );
  
  const displayText = text.slice(0, charCount);
  const isComplete = charCount >= text.length;
  
  // Blink cursor when typing, solid when done (for a bit)
  const cursorOpacity = isComplete 
    ? (Math.floor(frame / 8) % 2 === 0 ? 1 : 0) // Slow blink when done
    : (Math.floor(frame / 4) % 2 === 0 ? 1 : 0); // Fast blink while typing

  return (
    <span className={className} style={style}>
      {displayText}
      <span
        style={{
          color: cursorColor,
          opacity: cursorOpacity,
          fontWeight: 300,
        }}
      >
        │
      </span>
    </span>
  );
};

// NEW: Word-by-word reveal for subtitles
interface WordRevealProps {
  text: string;
  startFrame?: number;
  wordsPerSecond?: number;
  className?: string;
  style?: React.CSSProperties;
}

export const WordReveal: React.FC<WordRevealProps> = ({
  text,
  startFrame = 0,
  wordsPerSecond = 4,
  className = "",
  style = {},
}) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  
  const words = text.split(" ");
  const framesPerWord = fps / wordsPerSecond;
  const elapsedFrames = Math.max(0, frame - startFrame);
  const wordCount = Math.min(words.length, Math.floor(elapsedFrames / framesPerWord));
  
  return (
    <span className={className} style={style}>
      {words.map((word, index) => {
        const isVisible = index < wordCount;
        return (
          <span
            key={index}
            style={{
              opacity: isVisible ? 1 : 0,
              transition: "opacity 0.1s ease-out",
              marginRight: "0.3em",
            }}
          >
            {word}
          </span>
        );
      })}
    </span>
  );
};

export const TypewriterCode: React.FC<{
  code: string;
  startFrame?: number;
  speed?: number;
}> = ({ code, startFrame = 0, speed = 2 }) => {
  const frame = useCurrentFrame();

  const lines = code.split("\n");
  const charsPerFrame = speed;
  const totalCharsShown = Math.max(0, (frame - startFrame) * charsPerFrame);

  let charCount = 0;
  const displayedLines = lines.map((line) => {
    if (charCount >= totalCharsShown) return "";
    const remainingChars = totalCharsShown - charCount;
    const lineToShow = line.slice(0, remainingChars);
    charCount += line.length + 1; // +1 for newline
    return lineToShow;
  });

  const showCursor = frame < startFrame + code.length / charsPerFrame + 10;

  return (
    <div
      style={{
        fontFamily: FONTS.mono,
        fontSize: "14px",
        lineHeight: "1.6",
        color: COLORS.textSecondary,
      }}
    >
      {displayedLines.map((line, i) => (
        <div key={i} style={{ display: "flex" }}>
          <span style={{ color: COLORS.textFaint, width: "40px", userSelect: "none" }}>
            {(i + 1).toString().padStart(2, "0")}
          </span>
          <span>
            {line}
            {i === displayedLines.length - 1 && showCursor && (
              <span
                style={{
                  color: COLORS.emerald[500],
                  opacity: Math.floor(frame / 5) % 2 === 0 ? 1 : 0,
                }}
              >
                │
              </span>
            )}
          </span>
        </div>
      ))}
    </div>
  );
};
