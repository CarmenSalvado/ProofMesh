import React from "react";
import {
  AbsoluteFill,
  useCurrentFrame,
  useVideoConfig,
  interpolate,
  Easing,
} from "remotion";
import { CLEAN_STYLES } from "./CleanStyles";

interface TextSlideProps {
  title?: string;
  subtitle?: string;
  lines?: string[];
  centered?: boolean;
}

export const TextSlide: React.FC<TextSlideProps> = ({
  title,
  subtitle,
  lines = [],
  centered = true,
}) => {
  const frame = useCurrentFrame();
  useVideoConfig();

  // Typewriter effect for title
  const getTypewriterProgress = (startFrame: number, speed: number = 2) => {
    return Math.max(0, (frame - startFrame) * speed);
  };

  // Title typewriter (fast)
  const titleStartFrame = 5;
  const titleSpeed = 2.5; // chars per frame
  const titleCharCount = title ? Math.min(
    title.length,
    Math.floor(getTypewriterProgress(titleStartFrame, titleSpeed))
  ) : 0;
  const titleText = title ? title.slice(0, titleCharCount) : "";
  const titleComplete = titleCharCount >= (title?.length || 0);

  // Subtitle typewriter (starts after title)
  const subtitleStartFrame = titleStartFrame + (title?.length || 0) / titleSpeed + 8;
  const subtitleSpeed = 2;
  const subtitleCharCount = subtitle ? Math.min(
    subtitle.length,
    Math.floor(getTypewriterProgress(subtitleStartFrame, subtitleSpeed))
  ) : 0;
  const subtitleText = subtitle ? subtitle.slice(0, subtitleCharCount) : "";
  const subtitleComplete = subtitleCharCount >= (subtitle?.length || 0);

  // Cursor blink
  const titleCursorOpacity = titleComplete
    ? (Math.floor(frame / 12) % 2 === 0 ? 0.5 : 0)
    : (Math.floor(frame / 4) % 2 === 0 ? 1 : 0);
  
  const subtitleCursorOpacity = subtitleComplete
    ? (Math.floor(frame / 12) % 2 === 0 ? 0.5 : 0)
    : (Math.floor(frame / 4) % 2 === 0 ? 1 : 0);

  // Fade in animation for lines (word by word)
  const getLineWordProgress = (lineIndex: number, wordIndex: number) => {
    const lineStartFrame = subtitleStartFrame + (subtitle?.length || 0) / subtitleSpeed + 10 + lineIndex * 20;
    const wordStartFrame = lineStartFrame + wordIndex * 4;
    return interpolate(
      frame,
      [wordStartFrame, wordStartFrame + 8],
      [0, 1],
      { extrapolateLeft: "clamp", extrapolateRight: "clamp", easing: Easing.out(Easing.quad) }
    );
  };

  return (
    <AbsoluteFill
      style={{
        backgroundColor: CLEAN_STYLES.colors.white,
        display: "flex",
        flexDirection: "column",
        alignItems: centered ? "center" : "flex-start",
        justifyContent: "center",
        padding: centered ? "0 120px" : "0 180px",
        fontFamily: CLEAN_STYLES.fonts.geistPixel,
      }}
    >
      {title && (
        <h1
          style={{
            fontSize: "72px",
            fontWeight: 700,
            color: CLEAN_STYLES.colors.black,
            margin: 0,
            marginBottom: subtitle || lines.length > 0 ? "24px" : 0,
            textAlign: centered ? "center" : "left",
            lineHeight: 1.1,
            minHeight: "86px", // Prevent layout shift
          }}
        >
          {titleText}
          <span
            style={{
              color: "#10B981",
              opacity: titleCursorOpacity,
              fontWeight: 300,
            }}
          >
            │
          </span>
        </h1>
      )}

      {subtitle && (
        <h2
          style={{
            fontSize: "40px",
            fontWeight: 400,
            color: CLEAN_STYLES.colors.gray[800],
            margin: 0,
            marginBottom: lines.length > 0 ? "32px" : 0,
            textAlign: centered ? "center" : "left",
            lineHeight: 1.3,
            minHeight: "52px",
          }}
        >
          {subtitleText}
          <span
            style={{
              color: "#10B981",
              opacity: subtitleCursorOpacity,
              fontWeight: 300,
            }}
          >
            │
          </span>
        </h2>
      )}

      {lines.map((line, lineIndex) => {
        const words = line.split(" ");
        return (
          <p
            key={lineIndex}
            style={{
              fontSize: "32px",
              fontWeight: 400,
              color: CLEAN_STYLES.colors.black,
              margin: 0,
              marginBottom: lineIndex < lines.length - 1 ? "20px" : 0,
              textAlign: centered ? "center" : "left",
              lineHeight: 1.4,
            }}
          >
            {words.map((word, wordIndex) => {
              const progress = getLineWordProgress(lineIndex, wordIndex);
              return (
                <span
                  key={wordIndex}
                  style={{
                    opacity: progress,
                    marginRight: "0.3em",
                    transition: "opacity 0.05s ease-out",
                  }}
                >
                  {word}
                </span>
              );
            })}
          </p>
        );
      })}
    </AbsoluteFill>
  );
};
