import {
  AbsoluteFill,
  interpolate,
  spring,
  useCurrentFrame,
  useVideoConfig,
} from "remotion";
import { Brain } from "./Icons";
import { CLEAN_STYLES } from "./CleanStyles";

export const CleanLogo: React.FC<{ showText?: boolean }> = ({ showText = true }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  // Faster spring animation
  const scale = spring({
    frame,
    config: {
      damping: 150,
      mass: 0.5,
      stiffness: 200, // Faster
    },
    fps,
  });

  const opacity = spring({
    frame,
    config: {
      damping: 80,
      stiffness: 150,
    },
    fps,
  });

  const rotate = interpolate(
    frame,
    [0, 20],
    [0, 360],
    { extrapolateRight: "clamp" }
  );

  // Typewriter effect for "ProofMesh" text
  const fullText = "ProofMesh";
  const textStartFrame = 25; // Start after logo animation
  const charsPerFrame = 2.5;
  
  const textCharCount = showText ? Math.min(
    fullText.length,
    Math.max(0, Math.floor((frame - textStartFrame) * charsPerFrame))
  ) : 0;
  
  const displayText = fullText.slice(0, textCharCount);
  const textComplete = textCharCount >= fullText.length;
  
  // Cursor blink
  const cursorOpacity = textComplete
    ? (Math.floor(frame / 12) % 2 === 0 ? 0.5 : 0)
    : (Math.floor(frame / 4) % 2 === 0 ? 1 : 0);

  return (
    <AbsoluteFill
      style={{
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        backgroundColor: CLEAN_STYLES.colors.white,
      }}
    >
      <div
        style={{
          transform: `scale(${scale})`,
          opacity,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
        }}
      >
        {/* Icon container with subtle rotation animation */}
        <div
          style={{
            width: 100,
            height: 100,
            borderRadius: "20px",
            background: `linear-gradient(135deg, #6366F1, #10B981)`,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            transform: `rotate(${rotate * 0.02}deg)`,
            boxShadow: `0 0 50px rgba(99, 102, 241, ${0.25 * opacity})`,
          }}
        >
          <Brain size={50} color="#ffffff" />
        </div>

        {showText && (
          <h1
            style={{
              marginTop: "28px",
              fontSize: "64px",
              fontWeight: 700,
              color: CLEAN_STYLES.colors.black,
              letterSpacing: "-0.02em",
              fontFamily: CLEAN_STYLES.fonts.geistPixel,
              minHeight: "77px", // Prevent layout shift
              display: "flex",
              alignItems: "center",
            }}
          >
            {displayText}
            <span
              style={{
                color: "#10B981",
                opacity: cursorOpacity,
                fontWeight: 300,
                marginLeft: "2px",
              }}
            >
              │
            </span>
          </h1>
        )}
      </div>
    </AbsoluteFill>
  );
};
