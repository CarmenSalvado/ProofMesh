import React from "react";
import { useCurrentFrame, useVideoConfig, interpolate, spring, Easing } from "remotion";
import { COLORS, FONTS } from "./ProofMeshStyles";
import { Bot, Search, FileCode, Zap } from "./Icons";

interface AgentBadgeProps {
  name: string;
  icon: "bot" | "search" | "filecode" | "zap";
  color: string;
  x: number;
  y: number;
  startFrame?: number;
  isActive?: boolean;
  pulse?: boolean;
}

const IconComponent: React.FC<{ type: string; size?: number; color?: string }> = ({ type, size = 16, color }) => {
  switch (type) {
    case "bot": return <Bot size={size} color={color} />;
    case "search": return <Search size={size} color={color} />;
    case "filecode": return <FileCode size={size} color={color} />;
    case "zap": return <Zap size={size} color={color} />;
    default: return <Bot size={size} color={color} />;
  }
};

export const AgentBadge: React.FC<AgentBadgeProps> = ({
  name,
  icon,
  color,
  x,
  y,
  startFrame = 0,
  isActive = false,
  pulse = false,
}) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  const progress = spring({
    frame: frame - startFrame,
    fps,
    config: { damping: 200 },
  });

  const floatY = interpolate(
    frame,
    [0, 30, 60],
    [0, -6, 0],
    {
      extrapolateRight: "extend",
      easing: Easing.inOut(Easing.sin),
    }
  );

  const pulseScale = pulse
    ? 1 + interpolate(
        frame % 30,
        [0, 15, 30],
        [0, 0.05, 0],
        { extrapolateRight: "clamp" }
      )
    : 1;

  return (
    <div
      style={{
        position: "absolute",
        left: x,
        top: y + floatY,
        transform: `translate(-50%, -50%) scale(${progress * pulseScale})`,
        opacity: progress,
        backgroundColor: COLORS.bgSecondary,
        border: `1px solid ${color}40`,
        padding: "10px 16px",
        borderRadius: "999px",
        display: "flex",
        alignItems: "center",
        gap: "8px",
        boxShadow: isActive ? `0 0 30px ${color}40` : "0 4px 6px rgba(0, 0, 0, 0.3)",
      }}
    >
      <IconComponent type={icon} size={16} color={isActive ? color : COLORS.textMuted} />
      <span
        style={{
          color: isActive ? color : COLORS.textSecondary,
          fontWeight: 600,
          fontSize: "13px",
          fontFamily: FONTS.sans,
        }}
      >
        {name}
      </span>
      {isActive && (
        <span
          style={{
            width: 6,
            height: 6,
            borderRadius: "50%",
            backgroundColor: color,
            boxShadow: `0 0 8px ${color}`,
          }}
        />
      )}
    </div>
  );
};

export const AgentOrbit: React.FC<{ startFrame?: number }> = ({
  startFrame = 0,
}) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  const agents = [
    { name: "Explorer", icon: "search" as const, color: COLORS.indigo[500], angle: 0 },
    { name: "Prover", icon: "filecode" as const, color: COLORS.emerald[500], angle: 120 },
    { name: "Verifier", icon: "zap" as const, color: COLORS.amber[500], angle: 240 },
  ];

  const rotation = interpolate(
    frame,
    [startFrame, startFrame + 300],
    [0, 360],
    { extrapolateRight: "extend" }
  );

  return (
    <div
      style={{
        position: "absolute",
        left: 960,
        top: 540,
        width: 360,
        height: 360,
        transform: "translate(-50%, -50%)",
      }}
    >
      {/* Orbit ring */}
      <div
        style={{
          position: "absolute",
          inset: 0,
          borderRadius: "50%",
          border: `1px dashed ${COLORS.borderSecondary}`,
          opacity: 0.5,
        }}
      />

      {agents.map((agent, i) => {
        const rad = (((agent.angle + rotation) * Math.PI) / 180);
        const x = Math.cos(rad) * 130;
        const y = Math.sin(rad) * 130;

        const agentProgress = spring({
          frame: frame - startFrame - i * 12,
          fps,
          config: { damping: 200 },
        });

        return (
          <div
            key={agent.name}
            style={{
              position: "absolute",
              left: 180 + x,
              top: 180 + y,
              transform: `translate(-50%, -50%) rotate(${-agent.angle - rotation}deg) scale(${agentProgress})`,
              opacity: agentProgress,
              backgroundColor: COLORS.bgSecondary,
              border: `1px solid ${agent.color}50`,
              padding: "12px 18px",
              borderRadius: "12px",
              boxShadow: `0 10px 30px rgba(0,0,0,0.4), 0 0 20px ${agent.color}30`,
              display: "flex",
              alignItems: "center",
              gap: "8px",
            }}
          >
            <IconComponent type={agent.icon} size={18} color={agent.color} />
            <span
              style={{
                color: agent.color,
                fontWeight: 700,
                fontSize: "14px",
                fontFamily: FONTS.sans,
              }}
            >
              {agent.name}
            </span>
          </div>
        );
      })}

      {/* Center hub - Gemini */}
      <div
        style={{
          position: "absolute",
          left: 180,
          top: 180,
          transform: "translate(-50%, -50%)",
          width: 70,
          height: 70,
          borderRadius: "50%",
          background: `linear-gradient(135deg, ${COLORS.indigo[500]}, ${COLORS.emerald[500]})`,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          boxShadow: `0 0 50px ${COLORS.indigo[500]}50`,
        }}
      >
        <Bot size={32} color="#ffffff" />
      </div>
    </div>
  );
};

export const AgentThinking: React.FC<{
  startFrame?: number;
  x?: number;
  y?: number;
}> = ({ startFrame = 0, x = 960, y = 500 }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  const progress = spring({
    frame: frame - startFrame,
    fps,
    config: { damping: 200 },
  });

  return (
    <div
      style={{
        position: "absolute",
        left: x,
        top: y,
        transform: `translate(-50%, -50%) scale(${progress})`,
        opacity: progress,
        backgroundColor: COLORS.bgTertiary,
        border: `1px solid ${COLORS.borderSecondary}`,
        borderRadius: "10px",
        padding: "12px 16px",
        display: "flex",
        alignItems: "center",
        gap: "12px",
        boxShadow: "0 8px 30px rgba(0,0,0,0.4)",
      }}
    >
      <Bot size={16} color={COLORS.textSecondary} />
      <span
        style={{
          fontSize: "13px",
          color: COLORS.textMuted,
          fontFamily: FONTS.sans,
        }}
      >
        Gemini is thinking
      </span>
      <div style={{ display: "flex", gap: "4px" }}>
        {[0, 1, 2].map((i) => (
          <div
            key={i}
            style={{
              width: 5,
              height: 5,
              borderRadius: "50%",
              backgroundColor: COLORS.emerald[500],
              opacity: interpolate(
                (frame + i * 10) % 40,
                [0, 20, 40],
                [0.3, 1, 0.3]
              ),
            }}
          />
        ))}
      </div>
    </div>
  );
};
