import React from "react";
import { useCurrentFrame, useVideoConfig, interpolate, spring } from "remotion";
import { COLORS, FONTS, NODE_TYPE_CONFIG, STATUS_CONFIG } from "./ProofMeshStyles";
import { Check } from "./Icons";

interface GraphNode {
  id: string;
  x: number;
  y: number;
  label: string;
  type: keyof typeof NODE_TYPE_CONFIG;
  status: keyof typeof STATUS_CONFIG;
  author?: string;
  formula?: string;
}

const NODES: GraphNode[] = [
  { id: "1", x: 280, y: 420, label: "Definition 1", type: "DEFINITION", status: "VERIFIED" },
  { id: "2", x: 480, y: 320, label: "Lemma 1", type: "LEMMA", status: "VERIFIED" },
  { id: "3", x: 480, y: 520, label: "Lemma 2", type: "LEMMA", status: "VERIFIED" },
  { id: "4", x: 680, y: 370, label: "Theorem X", type: "THEOREM", status: "PROPOSED" },
  { id: "5", x: 680, y: 470, label: "Theorem Y", type: "THEOREM", status: "VERIFIED" },
  { id: "6", x: 880, y: 420, label: "Main Result", type: "CLAIM", status: "VERIFIED", author: "Alice" },
];

const EDGES = [
  { from: "1", to: "2" },
  { from: "1", to: "3" },
  { from: "2", to: "4" },
  { from: "3", to: "4" },
  { from: "2", to: "5" },
  { from: "3", to: "5" },
  { from: "4", to: "6" },
  { from: "5", to: "6" },
];

export const NodeGraph: React.FC<{
  startFrame?: number;
  highlightNode?: string;
  showVerification?: boolean;
}> = ({ startFrame = 0, highlightNode, showVerification = false }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  return (
    <svg
      style={{
        position: "absolute",
        inset: 0,
        width: "100%",
        height: "100%",
      }}
    >
      <defs>
        <filter id="nodeGlow" x="-50%" y="-50%" width="200%" height="200%">
          <feGaussianBlur stdDeviation="4" result="coloredBlur" />
          <feMerge>
            <feMergeNode in="coloredBlur" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
        <marker
          id="arrowhead"
          markerWidth="8"
          markerHeight="6"
          refX="26"
          refY="3"
          orient="auto"
        >
          <polygon points="0 0, 8 3, 0 6" fill={COLORS.borderSecondary} />
        </marker>
      </defs>

      {/* Edges */}
      {EDGES.map((edge, i) => {
        const fromNode = NODES.find((n) => n.id === edge.from);
        const toNode = NODES.find((n) => n.id === edge.to);
        if (!fromNode || !toNode) return null;

        const edgeProgress = spring({
          frame: frame - startFrame - i * 4,
          fps,
          config: { damping: 200 },
        });

        const isHighlighted =
          highlightNode && (edge.from === highlightNode || edge.to === highlightNode);

        return (
          <line
            key={`${edge.from}-${edge.to}`}
            x1={fromNode.x}
            y1={fromNode.y}
            x2={fromNode.x + (toNode.x - fromNode.x) * edgeProgress}
            y2={fromNode.y + (toNode.y - fromNode.y) * edgeProgress}
            stroke={isHighlighted ? COLORS.indigo[500] : COLORS.borderSecondary}
            strokeWidth={isHighlighted ? 2 : 1}
            opacity={edgeProgress * (isHighlighted ? 0.8 : 0.4)}
            markerEnd={edgeProgress > 0.9 ? "url(#arrowhead)" : undefined}
          />
        );
      })}

      {/* Nodes */}
      {NODES.map((node, i) => {
        const nodeProgress = spring({
          frame: frame - startFrame - i * 6,
          fps,
          config: { damping: 200 },
        });

        const typeConfig = NODE_TYPE_CONFIG[node.type];
        const isHighlighted = node.id === highlightNode;
        const verificationFrame = startFrame + 80 + i * 15;
        const isVerifying = showVerification && node.status === "PROPOSED" && frame > verificationFrame;
        const verificationProgress = isVerifying
          ? interpolate(frame, [verificationFrame, verificationFrame + 30], [0, 1], {
              extrapolateLeft: "clamp",
              extrapolateRight: "clamp",
            })
          : 0;

        const isVerified = node.status === "VERIFIED" || (isVerifying && verificationProgress > 0.5);
        const statusColor = isVerified ? COLORS.emerald[500] : typeConfig.color;

        return (
          <g key={node.id}>
            {/* Glow effect */}
            {(isHighlighted || isVerified) && (
              <circle
                cx={node.x}
                cy={node.y}
                r={32}
                fill={statusColor}
                opacity={0.15 * nodeProgress}
                filter="url(#nodeGlow)"
              />
            )}

            {/* Main node circle */}
            <circle
              cx={node.x}
              cy={node.y}
              r={22 * nodeProgress}
              fill={COLORS.bgSecondary}
              stroke={statusColor}
              strokeWidth={isHighlighted ? 3 : 2}
            />

            {/* Type icon in center */}
            <text
              x={node.x}
              y={node.y + 4}
              textAnchor="middle"
              fill={typeConfig.color}
              fontSize="11"
              fontWeight="700"
              opacity={nodeProgress}
              style={{ fontFamily: FONTS.sans }}
            >
              {node.type[0]}
            </text>

            {/* Verified checkmark */}
            {isVerified && (
              <g transform={`translate(${node.x + 14}, ${node.y - 14})`} opacity={nodeProgress}>
                <circle r={8} fill={COLORS.emerald[500]} />
                <Check size={10} color="#ffffff" />
              </g>
            )}

            {/* Node label */}
            <text
              x={node.x}
              y={node.y + 40}
              textAnchor="middle"
              fill={isHighlighted ? COLORS.textPrimary : COLORS.textSecondary}
              fontSize="12"
              fontWeight={isHighlighted ? 600 : 500}
              opacity={nodeProgress}
              style={{ fontFamily: FONTS.sans }}
            >
              {node.label}
            </text>

            {/* Type badge */}
            <g transform={`translate(${node.x - 35}, ${node.y - 50})`} opacity={nodeProgress}>
              <rect
                x={0}
                y={0}
                width={70}
                height={18}
                rx={9}
                fill={typeConfig.bgColor}
                stroke={typeConfig.borderColor}
                strokeWidth={1}
              />
              <text
                x={35}
                y={13}
                textAnchor="middle"
                fill={typeConfig.color}
                fontSize="8"
                fontWeight={700}
                style={{ fontFamily: FONTS.sans }}
              >
                {typeConfig.label.toUpperCase()}
              </text>
            </g>

            {/* Author tooltip */}
            {node.author && (isHighlighted || frame > startFrame + 100) && (
              <g>
                <rect
                  x={node.x - 60}
                  y={node.y - 80}
                  width={120}
                  height={36}
                  rx={8}
                  fill={COLORS.bgTertiary}
                  stroke={COLORS.borderSecondary}
                  strokeWidth={1}
                  opacity={interpolate(
                    frame,
                    [startFrame + 100, startFrame + 120],
                    [0, 1],
                    { extrapolateRight: "clamp" }
                  )}
                />
                <text
                  x={node.x}
                  y={node.y - 58}
                  textAnchor="middle"
                  fill={COLORS.textMuted}
                  fontSize="10"
                  style={{ fontFamily: FONTS.sans }}
                  opacity={interpolate(
                    frame,
                    [startFrame + 100, startFrame + 120],
                    [0, 1],
                    { extrapolateRight: "clamp" }
                  )}
                >
                  Proposed by {node.author}
                </text>
              </g>
            )}
          </g>
        );
      })}
    </svg>
  );
};

export const GraphCard: React.FC<{
  startFrame?: number;
}> = ({ startFrame = 0 }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  const progress = spring({
    frame: frame - startFrame,
    fps,
    config: { damping: 200 },
  });

  return (
    <div
      style={{
        position: "absolute",
        left: 960,
        top: 540,
        transform: `translate(-50%, -50%) scale(${progress})`,
        opacity: progress,
        width: 1000,
        height: 600,
        backgroundColor: COLORS.bgSecondary,
        border: `1px solid ${COLORS.borderPrimary}`,
        borderRadius: "16px",
        boxShadow: "0 20px 50px rgba(0,0,0,0.5)",
        overflow: "hidden",
      }}
    >
      {/* Header - matching Canvas header */}
      <div
        style={{
          backgroundColor: COLORS.bgTertiary,
          borderBottom: `1px solid ${COLORS.borderPrimary}`,
          padding: "14px 20px",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
        }}
      >
        <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
          <Network size={18} color={COLORS.textSecondary} />
          <span
            style={{
              fontSize: "14px",
              fontWeight: 600,
              color: COLORS.textPrimary,
              fontFamily: FONTS.sans,
            }}
          >
            Knowledge Graph
          </span>
        </div>
        <div style={{ display: "flex", gap: "8px" }}>
          {["All", "Verified", "Pending"].map((tab, i) => (
            <span
              key={tab}
              style={{
                padding: "4px 12px",
                borderRadius: "999px",
                fontSize: "11px",
                backgroundColor: i === 0 ? "rgba(255,255,255,0.06)" : "transparent",
                border: `1px solid ${i === 0 ? COLORS.borderSecondary : "transparent"}`,
                color: i === 0 ? COLORS.textPrimary : COLORS.textMuted,
                fontFamily: FONTS.sans,
              }}
            >
              {tab}
            </span>
          ))}
        </div>
      </div>

      {/* Graph content */}
      <div style={{ position: "relative", width: "100%", height: "calc(100% - 60px)" }}>
        <NodeGraph startFrame={startFrame + 20} showVerification />
      </div>
    </div>
  );
};

// Need to import Network here to avoid circular dependency
const Network: React.FC<{ size?: number; color?: string }> = ({ size = 20, color = "currentColor" }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="none"
    stroke={color}
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <circle cx="12" cy="5" r="3" />
    <circle cx="5" cy="19" r="3" />
    <circle cx="19" cy="19" r="3" />
    <path d="M12 8v4" />
    <path d="m7 17 3-3" />
    <path d="m17 17-3-3" />
  </svg>
);
