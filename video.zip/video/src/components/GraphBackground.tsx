import React from "react";
import { useCurrentFrame, useVideoConfig, interpolate, spring, random } from "remotion";
import { COLORS, FONTS } from "./ProofMeshStyles";

interface Node {
  id: string;
  x: number;
  y: number;
  label: string;
  color: string;
  type: string;
}

interface Edge {
  from: string;
  to: string;
}

const NODES: Node[] = [
  { id: "A", x: 250, y: 350, label: "Def 1", color: COLORS.indigo[500], type: "DEFINITION" },
  { id: "B", x: 450, y: 250, label: "Lemma 1", color: COLORS.emerald[500], type: "LEMMA" },
  { id: "C", x: 450, y: 450, label: "Lemma 2", color: COLORS.emerald[500], type: "LEMMA" },
  { id: "D", x: 700, y: 300, label: "Theorem", color: COLORS.amber[500], type: "THEOREM" },
  { id: "E", x: 700, y: 400, label: "Claim", color: COLORS.zinc[500], type: "CLAIM" },
  { id: "F", x: 950, y: 350, label: "Result", color: COLORS.amber[500], type: "THEOREM" },
];

const EDGES: Edge[] = [
  { from: "A", to: "B" },
  { from: "A", to: "C" },
  { from: "B", to: "D" },
  { from: "C", to: "D" },
  { from: "B", to: "E" },
  { from: "C", to: "E" },
  { from: "D", to: "F" },
  { from: "E", to: "F" },
];

export const GraphBackground: React.FC<{
  animated?: boolean;
  opacity?: number;
  startFrame?: number;
}> = ({ animated = true, opacity = 0.15, startFrame = 0 }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  const scale = animated
    ? spring({
        frame: frame - startFrame,
        fps,
        config: { damping: 200 },
        durationInFrames: 60,
      })
    : 1;

  return (
    <svg
      style={{
        position: "absolute",
        inset: 0,
        width: "100%",
        height: "100%",
        opacity,
        transform: `scale(${0.95 + scale * 0.05})`,
      }}
    >
      <defs>
        <filter id="glow" x="-50%" y="-50%" width="200%" height="200%">
          <feGaussianBlur stdDeviation="3" result="coloredBlur" />
          <feMerge>
            <feMergeNode in="coloredBlur" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
      </defs>

      {/* Edges */}
      {EDGES.map((edge, i) => {
        const fromNode = NODES.find((n) => n.id === edge.from);
        const toNode = NODES.find((n) => n.id === edge.to);
        if (!fromNode || !toNode) return null;

        const edgeProgress = animated
          ? interpolate(
              frame - startFrame,
              [i * 8, i * 8 + 25],
              [0, 1],
              { extrapolateLeft: "clamp", extrapolateRight: "clamp" }
            )
          : 1;

        const x1 = fromNode.x;
        const y1 = fromNode.y;
        const x2 = x1 + (toNode.x - x1) * edgeProgress;
        const y2 = y1 + (toNode.y - y1) * edgeProgress;

        return (
          <line
            key={`${edge.from}-${edge.to}`}
            x1={x1}
            y1={y1}
            x2={x2}
            y2={y2}
            stroke={COLORS.borderSecondary}
            strokeWidth="1"
            opacity={0.6}
          />
        );
      })}

      {/* Nodes */}
      {NODES.map((node, i) => {
        const nodeProgress = animated
          ? interpolate(
              frame - startFrame,
              [i * 6, i * 6 + 18],
              [0, 1],
              { extrapolateLeft: "clamp", extrapolateRight: "clamp" }
            )
          : 1;

        return (
          <g key={node.id} filter="url(#glow)">
            <circle
              cx={node.x}
              cy={node.y}
              r={18 * nodeProgress}
              fill={node.color}
              opacity={nodeProgress * 0.8}
            />
            <text
              x={node.x}
              y={node.y + 4}
              textAnchor="middle"
              fill="#ffffff"
              fontSize="9"
              fontWeight="700"
              opacity={nodeProgress}
              style={{ fontFamily: FONTS.sans }}
            >
              {node.type[0]}
            </text>
          </g>
        );
      })}
    </svg>
  );
};

export const AnimatedGraph: React.FC<{ 
  showCheckmarks?: boolean;
  startFrame?: number;
}> = ({ showCheckmarks = false, startFrame = 0 }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  const nodeCount = 12;
  const nodes = React.useMemo(() => {
    return Array.from({ length: nodeCount }, (_, i) => ({
      id: i,
      x: 150 + random(i) * 800,
      y: 100 + random(i + 100) * 500,
      verified: i < 8,
    }));
  }, []);

  return (
    <svg
      style={{
        position: "absolute",
        inset: 0,
        width: "100%",
        height: "100%",
      }}
    >
      {nodes.map((node, i) => {
        const nodeFrame = frame - startFrame - i * 4;
        const nodeScale = spring({
          frame: nodeFrame,
          fps,
          config: { damping: 200 },
        });

        if (nodeScale <= 0) return null;

        return (
          <g key={node.id}>
            <circle
              cx={node.x}
              cy={node.y}
              r={12 * nodeScale}
              fill={showCheckmarks && node.verified ? COLORS.emerald[500] : COLORS.indigo[500]}
              opacity={0.7}
            />
            {showCheckmarks && node.verified && nodeFrame > 30 && (
              <text
                x={node.x}
                y={node.y + 4}
                textAnchor="middle"
                fill="#ffffff"
                fontSize="12"
                fontWeight="bold"
              >
                {String.fromCharCode(10003)}
              </text>
            )}
          </g>
        );
      })}

      {/* Connecting lines */}
      {nodes.slice(0, Math.max(0, Math.floor((frame - startFrame) / 5))).map((node, i) => {
        if (i === 0) return null;
        const prevNode = nodes[i - 1];
        if (!prevNode) return null;
        return (
          <line
            key={`line-${i}`}
            x1={prevNode.x}
            y1={prevNode.y}
            x2={node.x}
            y2={node.y}
            stroke={COLORS.borderSecondary}
            strokeWidth="1"
            opacity={0.3}
          />
        );
      })}
    </svg>
  );
};
