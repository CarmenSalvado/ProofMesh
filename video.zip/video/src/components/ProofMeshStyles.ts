// ProofMesh Design System - Based on real frontend components
// Matches frontend/src/app/globals.css and component styles

// Colors from Tailwind config and globals.css
export const COLORS = {
  // Zinc scale (neutral)
  zinc: {
    50: "#fafafa",
    100: "#f4f4f5",
    200: "#e4e4e7",
    300: "#d4d4d8",
    400: "#a1a1aa",
    500: "#71717a",
    600: "#52525b",
    700: "#3f3f46",
    800: "#27272a",
    900: "#18181b",
    950: "#09090b",
  },

  // Backgrounds (Prism dark theme)
  bgPrimary: "#0a0a0a",
  bgSecondary: "#0d0d0d",
  bgTertiary: "#111111",
  bgHover: "#141414",
  
  // Text
  textPrimary: "#fafafa",
  textSecondary: "#a0a0a0",
  textMuted: "#707070",
  textFaint: "#505050",
  
  // Borders
  borderPrimary: "#1a1a1a",
  borderSecondary: "#252525",
  borderMuted: "#2a2a2a",
  
  // Accents
  indigo: {
    50: "#eef2ff",
    100: "#e0e7ff",
    500: "#6366f1",
    600: "#4f46e5",
    700: "#4338ca",
  },
  
  emerald: {
    50: "#ecfdf5",
    100: "#d1fae5",
    400: "#34d399",
    500: "#10b981",
    600: "#059669",
    700: "#047857",
  },
  
  amber: {
    50: "#fffbeb",
    100: "#fef3c7",
    500: "#f59e0b",
    600: "#d97706",
  },
  
  // Node type colors (from types.ts)
  nodeDefinition: { color: "#4338ca", bg: "#eef2ff", border: "#c7d2fe" },    // indigo
  nodeLemma: { color: "#047857", bg: "#ecfdf5", border: "#a7f3d0" },         // emerald
  nodeTheorem: { color: "#b45309", bg: "#fffbeb", border: "#fcd34d" },       // amber
  nodeClaim: { color: "#1d4ed8", bg: "#dbeafe", border: "#93c5fd" },         // blue
  nodeCounterexample: { color: "#b91c1c", bg: "#fee2e2", border: "#fca5a5" }, // red
  nodeComputation: { color: "#7e22ce", bg: "#f3e8ff", border: "#d8b4fe" },   // purple
  nodeNote: { color: "#3f3f46", bg: "#f4f4f5", border: "#e4e4e7" },          // zinc
  nodeResource: { color: "#334155", bg: "#f1f5f9", border: "#cbd5e1" },      // slate
  nodeIdea: { color: "#a21caf", bg: "#fdf4ff", border: "#f0abfc" },          // fuchsia
  nodeContent: { color: "#0891b2", bg: "#ecfeff", border: "#a5f3fc" },       // cyan
  
  // Status colors (from types.ts)
  statusVerified: { color: "#047857", bg: "#d1fae5", text: "#065f46" },     // emerald
  statusProposed: { color: "#b45309", bg: "#fef3c7", text: "#92400e" },      // amber
  statusRejected: { color: "#b91c1c", bg: "#fee2e2", text: "#991b1b" },      // red
  statusDraft: { color: "#52525b", bg: "#f4f4f5", text: "#3f3f46" },         // zinc
};

export const FONTS = {
  sans: "'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
  mono: "'JetBrains Mono', 'Fira Code', ui-monospace, monospace",
  math: "'Newsreader', 'Georgia', serif",
};

export const SHADOWS = {
  sm: "0 1px 2px rgba(0, 0, 0, 0.3)",
  md: "0 4px 6px rgba(0, 0, 0, 0.3)",
  lg: "0 8px 30px rgba(0, 0, 0, 0.4)",
  xl: "0 20px 50px rgba(0, 0, 0, 0.5)",
  glow: "0 0 60px rgba(99, 102, 241, 0.3)",
  glowSuccess: "0 0 40px rgba(16, 185, 129, 0.3)",
  card: "0 4px 20px rgb(0, 0, 0, 0.04)",
  cardHover: "0 4px 20px rgb(0, 0, 0, 0.08)",
};

// Node type config (from types.ts)
export const NODE_TYPE_CONFIG: Record<string, { label: string; color: string; bgColor: string; borderColor: string }> = {
  DEFINITION: {
    label: "Definition",
    color: "#4338ca",
    bgColor: "rgba(238, 242, 255, 0.1)",
    borderColor: "rgba(199, 210, 254, 0.3)",
  },
  LEMMA: {
    label: "Lemma",
    color: "#10b981",
    bgColor: "rgba(236, 253, 245, 0.1)",
    borderColor: "rgba(167, 243, 208, 0.3)",
  },
  THEOREM: {
    label: "Theorem",
    color: "#f59e0b",
    bgColor: "rgba(255, 251, 235, 0.1)",
    borderColor: "rgba(252, 211, 77, 0.3)",
  },
  CLAIM: {
    label: "Claim",
    color: "#3b82f6",
    bgColor: "rgba(219, 234, 254, 0.1)",
    borderColor: "rgba(147, 197, 253, 0.3)",
  },
  NOTE: {
    label: "Note",
    color: "#a1a1aa",
    bgColor: "rgba(244, 244, 245, 0.1)",
    borderColor: "rgba(228, 228, 231, 0.3)",
  },
  IDEA: {
    label: "Idea",
    color: "#d946ef",
    bgColor: "rgba(253, 244, 255, 0.1)",
    borderColor: "rgba(240, 171, 252, 0.3)",
  },
};

// Status config (from types.ts)
export const STATUS_CONFIG: Record<string, { label: string; color: string; bgColor: string; icon: React.ReactNode }> = {
  VERIFIED: {
    label: "Verified",
    color: "#10b981",
    bgColor: "rgba(16, 185, 129, 0.2)",
    icon: null, // Will use Check icon
  },
  PROPOSED: {
    label: "Proposed",
    color: "#f59e0b",
    bgColor: "rgba(245, 158, 11, 0.2)",
    icon: null,
  },
  DRAFT: {
    label: "Draft",
    color: "#71717a",
    bgColor: "rgba(113, 113, 122, 0.2)",
    icon: null,
  },
};

// Common component styles
export const panelStyle = {
  backgroundColor: COLORS.bgSecondary,
  border: `1px solid ${COLORS.borderPrimary}`,
  borderRadius: "12px",
  boxShadow: SHADOWS.lg,
};

export const cardStyle = {
  backgroundColor: "#ffffff",
  border: `1px solid ${COLORS.zinc[200]}`,
  borderRadius: "12px",
};

export const buttonPrimaryStyle = {
  backgroundColor: COLORS.indigo[600],
  color: "#ffffff",
  borderRadius: "8px",
  padding: "10px 20px",
  fontWeight: 500,
  fontSize: "14px",
};

export const buttonGhostStyle = {
  backgroundColor: "transparent",
  border: `1px solid ${COLORS.borderSecondary}`,
  color: COLORS.textSecondary,
  borderRadius: "6px",
  padding: "8px 16px",
  fontSize: "13px",
};

export const badgeStyle = (color: string, bgColor: string) => ({
  display: "inline-flex",
  alignItems: "center",
  padding: "4px 12px",
  borderRadius: "999px",
  fontSize: "12px",
  fontWeight: 600,
  color,
  backgroundColor: bgColor,
});
