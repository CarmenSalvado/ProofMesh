import React from "react";
import {
  AbsoluteFill,
  useCurrentFrame,
  useVideoConfig,
  interpolate,
} from "remotion";
import { CLEAN_STYLES } from "./CleanStyles";

interface AppClipPlaceholderProps {
  title?: string;
  description?: string;
}

export const AppClipPlaceholder: React.FC<AppClipPlaceholderProps> = ({
  title = "App Demo",
  description = "Replace with actual screen recording",
}) => {
  const frame = useCurrentFrame();
  useVideoConfig();

  const opacity = interpolate(frame, [0, 30], [0, 1], {
    extrapolateRight: "clamp",
  });

  const pulseScale = interpolate(
    frame,
    [0, 60, 120],
    [1, 1.02, 1],
    { extrapolateRight: "clamp" }
  );

  return (
    <AbsoluteFill
      style={{
        backgroundColor: CLEAN_STYLES.colors.white,
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        opacity,
      }}
    >
      {/* Placeholder box */}
      <div
        style={{
          width: 1400,
          height: 800,
          border: `3px dashed ${CLEAN_STYLES.colors.gray[200]}`,
          borderRadius: "24px",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          transform: `scale(${pulseScale})`,
          transition: "transform 0.1s ease-out",
          backgroundColor: CLEAN_STYLES.colors.gray[100],
        }}
      >
        {/* Play icon */}
        <div
          style={{
            width: 100,
            height: 100,
            borderRadius: "50%",
            backgroundColor: CLEAN_STYLES.colors.black,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            marginBottom: "32px",
          }}
        >
          <div
            style={{
              width: 0,
              height: 0,
              borderLeft: "40px solid white",
              borderTop: "24px solid transparent",
              borderBottom: "24px solid transparent",
              marginLeft: "10px",
            }}
          />
        </div>

        <h2
          style={{
            fontSize: "48px",
            fontWeight: 700,
            color: CLEAN_STYLES.colors.black,
            margin: 0,
            marginBottom: "16px",
            fontFamily: CLEAN_STYLES.fonts.geistPixel,
          }}
        >
          {title}
        </h2>

        <p
          style={{
            fontSize: "24px",
            color: CLEAN_STYLES.colors.gray[800],
            margin: 0,
            fontFamily: CLEAN_STYLES.fonts.geistPixel,
          }}
        >
          {description}
        </p>

        {/* Corner brackets to suggest video frame */}
        <div
          style={{
            position: "absolute",
            top: 24,
            left: 24,
            width: 40,
            height: 40,
            borderTop: `4px solid ${CLEAN_STYLES.colors.gray[200]}`,
            borderLeft: `4px solid ${CLEAN_STYLES.colors.gray[200]}`,
          }}
        />
        <div
          style={{
            position: "absolute",
            top: 24,
            right: 24,
            width: 40,
            height: 40,
            borderTop: `4px solid ${CLEAN_STYLES.colors.gray[200]}`,
            borderRight: `4px solid ${CLEAN_STYLES.colors.gray[200]}`,
          }}
        />
        <div
          style={{
            position: "absolute",
            bottom: 24,
            left: 24,
            width: 40,
            height: 40,
            borderBottom: `4px solid ${CLEAN_STYLES.colors.gray[200]}`,
            borderLeft: `4px solid ${CLEAN_STYLES.colors.gray[200]}`,
          }}
        />
        <div
          style={{
            position: "absolute",
            bottom: 24,
            right: 24,
            width: 40,
            height: 40,
            borderBottom: `4px solid ${CLEAN_STYLES.colors.gray[200]}`,
            borderRight: `4px solid ${CLEAN_STYLES.colors.gray[200]}`,
          }}
        />
      </div>
    </AbsoluteFill>
  );
};