import React from "react";
import {
	AbsoluteFill,
	OffthreadVideo,
	staticFile,
	useCurrentFrame,
	interpolate,
	Easing,
} from "remotion";

type FloatingSymbol = {
	char: string;
	top?: number;
	right?: number;
	bottom?: number;
	left?: number;
	size: number;
	color: string;
	rotate: number;
};

const FLOATING_SYMBOLS: FloatingSymbol[] = [
	{ char: "∫", top: 46, left: 58, size: 52, color: "rgba(129,140,248,0.45)", rotate: -8 },
	{ char: "√", top: 64, right: 74, size: 52, color: "rgba(34,211,238,0.42)", rotate: 9 },
	{ char: "∞", bottom: 52, left: 64, size: 50, color: "rgba(99,102,241,0.42)", rotate: -7 },
	{ char: "π", bottom: 54, right: 66, size: 48, color: "rgba(217,70,239,0.36)", rotate: 7 },
];

export const VibrantClipScene: React.FC<{
	src?: string;
	label: string;
	contentOnly?: boolean;
}> = ({ src, label, contentOnly = false }) => {
	const frame = useCurrentFrame();
	const opacity = interpolate(frame, [0, 12], [0, 1], {
		extrapolateRight: "clamp",
	});
	const inScale = interpolate(frame, [0, 20], [1.04, 1], {
		extrapolateRight: "clamp",
		easing: Easing.out(Easing.cubic),
	});
	const driftX = Math.sin(frame / 55) * 16;
	const driftY = Math.cos(frame / 62) * 12;
	const clipScale = 1.03 + Math.sin(frame / 85) * 0.012;
	const overlayOpacity = interpolate(frame, [0, 28], [0, 1], {
		extrapolateRight: "clamp",
	});
	const sweepX = interpolate(frame, [0, 130], [-900, 2200], {
		extrapolateLeft: "clamp",
		extrapolateRight: "clamp",
	});
	const sweepOpacity = interpolate(frame, [4, 24], [0, 0.7], {
		extrapolateLeft: "clamp",
		extrapolateRight: "clamp",
	});

	return (
		<AbsoluteFill
			style={{
				background: contentOnly ? "transparent" : "#ffffff",
				fontFamily: "var(--font-geist-sans)",
				padding: contentOnly ? 0 : 32,
			}}
		>
			{contentOnly ? null : (
				<div
					style={{
						position: "absolute",
						inset: 0,
						background:
							"radial-gradient(circle at 12% 8%, rgba(79,70,229,0.1) 0%, rgba(255,255,255,0) 50%), radial-gradient(circle at 88% 92%, rgba(6,182,212,0.1) 0%, rgba(255,255,255,0) 48%)",
					}}
				/>
			)}

			{FLOATING_SYMBOLS.map((symbol, i) => {
				const floatX = Math.cos((frame + i * 17) / 24) * 5;
				const floatY = Math.sin((frame + i * 13) / 20) * 6;
				return (
					<span
						key={`${symbol.char}-${i}`}
						style={{
							position: "absolute",
							top: symbol.top,
							right: symbol.right,
							bottom: symbol.bottom,
							left: symbol.left,
							fontFamily: "var(--font-geist-pixel-square)",
							fontSize: symbol.size,
							color: symbol.color,
							transform: `translate(${floatX}px, ${floatY}px) rotate(${symbol.rotate}deg)`,
							pointerEvents: "none",
							userSelect: "none",
							zIndex: 3,
							opacity: contentOnly ? 0.65 : 0.9,
						}}
					>
						{symbol.char}
					</span>
				);
			})}

			<div
				style={{
					position: "relative",
						width: "100%",
						height: "100%",
						borderRadius: contentOnly ? 0 : 28,
						overflow: "hidden",
						border: contentOnly ? "none" : "1px solid rgba(99,102,241,0.2)",
						boxShadow: contentOnly ? "none" : "0 28px 56px -36px rgba(15,23,42,0.45)",
						transform: `scale(${contentOnly ? 1 : inScale})`,
						opacity,
						background: "#f8fafc",
				}}
			>
				{src ? (
					<OffthreadVideo
						src={staticFile(src)}
						style={{
							width: "100%",
							height: "100%",
							objectFit: "cover",
							transform: `translate(${driftX}px, ${driftY}px) scale(${clipScale})`,
						}}
						muted
					/>
				) : (
					<div
						style={{
							width: "100%",
							height: "100%",
							display: "flex",
							flexDirection: "column",
							alignItems: "center",
							justifyContent: "center",
							color: "#334155",
							gap: 16,
							background:
								"linear-gradient(135deg, rgba(238,242,255,0.95) 0%, rgba(236,254,255,0.95) 100%)",
						}}
					>
						<div
							style={{
								fontFamily: "var(--font-geist-pixel-square)",
								fontSize: 78,
								color: "#0f172a",
							}}
						>
							{label}
						</div>
						<div style={{ fontSize: 34, fontWeight: 600 }}>Drop clip in `video/public/clips`</div>
						<div style={{ fontSize: 26, color: "#64748b" }}>
							Then set `src` in `VibrantMinimalDemo` composition props
						</div>
					</div>
				)}

				<div
					style={{
						position: "absolute",
						inset: 0,
						opacity: overlayOpacity,
						background:
							"linear-gradient(180deg, rgba(15,23,42,0.28) 0%, rgba(15,23,42,0.04) 25%, rgba(15,23,42,0) 45%, rgba(15,23,42,0.3) 100%)",
						pointerEvents: "none",
					}}
				/>

				<div
					style={{
						position: "absolute",
						top: -180,
						left: sweepX,
						width: 420,
						height: 1500,
						opacity: sweepOpacity,
						transform: "rotate(17deg)",
						background:
							"linear-gradient(90deg, rgba(255,255,255,0) 0%, rgba(255,255,255,0.26) 45%, rgba(165,243,252,0.24) 55%, rgba(255,255,255,0) 100%)",
						filter: "blur(12px)",
						pointerEvents: "none",
					}}
				/>

				<div
					style={{
						position: "absolute",
						left: 22,
						top: 18,
						display: "inline-flex",
						alignItems: "center",
						gap: 10,
						padding: "8px 16px",
						borderRadius: 999,
						background: "rgba(255,255,255,0.82)",
						border: "1px solid rgba(148,163,184,0.3)",
						fontSize: 19,
						fontWeight: 700,
						color: "#1e293b",
						backdropFilter: "blur(4px)",
						opacity: contentOnly ? 0.86 : 1,
					}}
				>
					<span
						style={{
							width: 8,
							height: 8,
							borderRadius: "50%",
							background: "#22c55e",
							boxShadow: "0 0 0 6px rgba(34,197,94,0.18)",
						}}
					/>
					{label}
				</div>

				<div
					style={{
						position: "absolute",
						right: 20,
						bottom: 26,
						fontSize: 17,
						fontWeight: 600,
						color: "#f8fafc",
						background: "rgba(15,23,42,0.48)",
						padding: "6px 10px",
						borderRadius: 12,
						border: "1px solid rgba(248,250,252,0.22)",
						opacity: contentOnly ? 0.86 : 1,
					}}
				>
					ProofMesh
				</div>
			</div>
		</AbsoluteFill>
	);
};
