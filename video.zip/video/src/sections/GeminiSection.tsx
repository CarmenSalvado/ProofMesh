import React from "react";
import { AbsoluteFill, useCurrentFrame, useVideoConfig, interpolate, spring, Easing } from "remotion";
import { COLORS, FONTS } from "../components/ProofMeshStyles";
import { Bot, Search, FileCode, Zap, Check } from "../components/Icons";

const AGENTS = [
  { name: "Explorer", icon: "search", color: COLORS.indigo[500], desc: "Explore ideas" },
  { name: "Formalizer", icon: "filecode", color: COLORS.amber[500], desc: "Translate to Lean" },
  { name: "Verifier", icon: "zap", color: COLORS.emerald[500], desc: "Assist verification" },
];

const LOOP_STEPS = [
  { icon: "search", label: "Explore" },
  { icon: "filecode", label: "Formalize" },
  { icon: "check", label: "Verify" },
];

const IconComponent: React.FC<{ type: string; size?: number; color?: string }> = ({ type, size = 16, color }) => {
  switch (type) {
    case "bot": return <Bot size={size} color={color} />;
    case "search": return <Search size={size} color={color} />;
    case "filecode": return <FileCode size={size} color={color} />;
    case "zap": return <Zap size={size} color={color} />;
    case "check": return <Check size={size} color={color} />;
    default: return <Bot size={size} color={color} />;
  }
};

export const GeminiSection: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  const titleProgress = spring({
    frame: frame - 5,
    fps,
    config: { damping: 200 },
  });

  return (
    <AbsoluteFill
      style={{
        backgroundColor: COLORS.bgPrimary,
        overflow: "hidden",
        fontFamily: FONTS.sans,
      }}
    >
      {/* Background gradient */}
      <div
        style={{
          position: "absolute",
          left: "50%",
          top: "50%",
          width: 800,
          height: 800,
          transform: "translate(-50%, -50%)",
          background: `radial-gradient(circle, ${COLORS.indigo[500]}10 0%, transparent 60%)`,
          opacity: 0.6,
        }}
      />

      {/* Main content */}
      <div
        style={{
          position: "absolute",
          inset: 0,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        {/* Gemini 3 Logo */}
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: "16px",
            marginBottom: "30px",
            opacity: titleProgress,
            transform: `scale(${0.9 + titleProgress * 0.1})`,
          }}
        >
          <div
            style={{
              width: 56,
              height: 56,
              borderRadius: "16px",
              background: `linear-gradient(135deg, #4285f4, #34a853, #fbbc05, #ea4335)`,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              boxShadow: `0 0 40px #4285f440`,
            }}
          >
            <span style={{ fontSize: "28px", color: "#ffffff", fontWeight: 700 }}>G</span>
          </div>
          <span
            style={{
              fontSize: "32px",
              fontWeight: 700,
              color: COLORS.textPrimary,
              fontFamily: FONTS.sans,
            }}
          >
            Gemini 3
          </span>
        </div>

        {/* Title */}
        <h2
          style={{
            fontSize: "44px",
            fontWeight: 700,
            color: COLORS.textPrimary,
            textAlign: "center",
            margin: 0,
            marginBottom: "16px",
            opacity: titleProgress,
            letterSpacing: "-0.02em",
            fontFamily: FONTS.sans,
          }}
        >
          Powered by{" "}
          <span
            style={{
              background: "linear-gradient(90deg, #4285f4, #34a853)",
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
            }}
          >
            Gemini 3
          </span>
        </h2>

        {/* Subtitle */}
        <p
          style={{
            fontSize: "20px",
            color: COLORS.textSecondary,
            textAlign: "center",
            maxWidth: "650px",
            lineHeight: 1.6,
            opacity: interpolate(frame, [30, 60], [0, 1]),
            marginBottom: "50px",
            fontFamily: FONTS.sans,
          }}
        >
          Explore ideas, translate them to Lean, and assist verification — always{" "}
          <span style={{ color: COLORS.textPrimary, fontWeight: 600 }}>human-in-the-loop</span>.
        </p>

        {/* Agent loop visualization */}
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: "20px",
            marginBottom: "60px",
          }}
        >
          {LOOP_STEPS.map((step, i) => {
            const stepProgress = spring({
              frame: frame - 60 - i * 20,
              fps,
              config: { damping: 200 },
            });

            const pulse = interpolate(
              (frame - i * 40) % 120,
              [0, 60, 120],
              [1, 1.1, 1],
              { easing: Easing.inOut(Easing.sin) }
            );

            return (
              <React.Fragment key={step.label}>
                <div
                  style={{
                    display: "flex",
                    flexDirection: "column",
                    alignItems: "center",
                    gap: "10px",
                    transform: `scale(${stepProgress * pulse})`,
                    opacity: stepProgress,
                  }}
                >
                  <div
                    style={{
                      width: 64,
                      height: 64,
                      borderRadius: "50%",
                      backgroundColor: COLORS.bgSecondary,
                      border: `1px solid ${COLORS.borderSecondary}`,
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      boxShadow: "0 4px 6px rgba(0, 0, 0, 0.3)",
                    }}
                  >
                    <IconComponent type={step.icon} size={28} color={COLORS.textSecondary} />
                  </div>
                  <span
                    style={{
                      fontSize: "13px",
                      color: COLORS.textMuted,
                      fontWeight: 500,
                      fontFamily: FONTS.sans,
                    }}
                  >
                    {step.label}
                  </span>
                </div>
                {i < LOOP_STEPS.length - 1 && (
                  <div
                    style={{
                      color: COLORS.borderSecondary,
                      fontSize: "20px",
                      opacity: stepProgress,
                      fontFamily: FONTS.sans,
                    }}
                  >
                    →
                  </div>
                )}
              </React.Fragment>
            );
          })}
        </div>

        {/* Agent badges */}
        <div
          style={{
            display: "flex",
            gap: "24px",
          }}
        >
          {AGENTS.map((agent, i) => {
            const agentProgress = spring({
              frame: frame - 100 - i * 15,
              fps,
              config: { damping: 200 },
            });

            return (
              <div
                key={agent.name}
                style={{
                  backgroundColor: COLORS.bgSecondary,
                  border: `1px solid ${agent.color}40`,
                  borderRadius: "14px",
                  padding: "20px 24px",
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  gap: "10px",
                  transform: `translateY(${(1 - agentProgress) * 30}px)`,
                  opacity: agentProgress,
                  boxShadow: `0 10px 30px ${agent.color}15`,
                  minWidth: 140,
                }}
              >
                <IconComponent type={agent.icon} size={28} color={agent.color} />
                <span
                  style={{
                    fontSize: "14px",
                    fontWeight: 600,
                    color: agent.color,
                    fontFamily: FONTS.sans,
                  }}
                >
                  {agent.name}
                </span>
                <span
                  style={{
                    fontSize: "11px",
                    color: COLORS.textMuted,
                    fontFamily: FONTS.sans,
                  }}
                >
                  {agent.desc}
                </span>
              </div>
            );
          })}
        </div>

        {/* Human-in-the-loop indicator */}
        <div
          style={{
            marginTop: "50px",
            display: "flex",
            alignItems: "center",
            gap: "12px",
            padding: "12px 20px",
            backgroundColor: COLORS.bgTertiary,
            border: `1px solid ${COLORS.borderSecondary}`,
            borderRadius: "999px",
            opacity: interpolate(frame, [150, 190], [0, 1]),
          }}
        >
          <Bot size={18} color={COLORS.textSecondary} />
          <span
            style={{
              fontSize: "13px",
              color: COLORS.textSecondary,
              fontFamily: FONTS.sans,
            }}
          >
            Always human-in-the-loop — you control every decision
          </span>
          <span
            style={{
              width: 8,
              height: 8,
              borderRadius: "50%",
              backgroundColor: COLORS.emerald[500],
              boxShadow: `0 0 10px ${COLORS.emerald[500]}`,
            }}
          />
        </div>
      </div>
    </AbsoluteFill>
  );
};
