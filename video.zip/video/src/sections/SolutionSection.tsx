import React from "react";
import { AbsoluteFill, useCurrentFrame, useVideoConfig, interpolate, spring } from "remotion";
import { GraphBackground } from "../components/GraphBackground";
import { AgentOrbit } from "../components/AgentBadge";
import { COLORS, FONTS } from "../components/ProofMeshStyles";
import { FileText, Network, Bot } from "../components/Icons";

const FEATURES = [
  { icon: "filetext", title: "Workspace", desc: "Organized thinking", color: COLORS.indigo[500] },
  { icon: "network", title: "Knowledge Graph", desc: "Connected ideas", color: COLORS.indigo[500] },
  { icon: "bot", title: "AI Agents", desc: "Smart assistance", color: COLORS.emerald[500] },
];

const IconComponent: React.FC<{ type: string; size?: number; color?: string }> = ({ type, size = 24, color }) => {
  switch (type) {
    case "filetext": return <FileText size={size} color={color} />;
    case "network": return <Network size={size} color={color} />;
    case "bot": return <Bot size={size} color={color} />;
    default: return <FileText size={size} color={color} />;
  }
};

export const SolutionSection: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  const titleProgress = spring({
    frame: frame - 5,
    fps,
    config: { damping: 200 },
  });

  return (
    <AbsoluteFill
      style={{
        backgroundColor: COLORS.bgPrimary,
        overflow: "hidden",
        fontFamily: FONTS.sans,
      }}
    >
      {/* Background */}
      <div style={{ opacity: 0.15 }}>
        <GraphBackground animated={false} />
      </div>

      {/* Gradient orb */}
      <div
        style={{
          position: "absolute",
          left: "50%",
          top: "30%",
          width: 600,
          height: 600,
          transform: "translate(-50%, -50%)",
          background: `radial-gradient(circle, ${COLORS.indigo[500]}15 0%, transparent 70%)`,
          opacity: interpolate(frame, [0, 60], [0, 1]),
        }}
      />

      {/* Main content */}
      <div
        style={{
          position: "absolute",
          inset: 0,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          padding: "80px",
        }}
      >
        {/* Section label */}
        <div
          style={{
            fontSize: "13px",
            fontWeight: 600,
            color: COLORS.emerald[500],
            textTransform: "uppercase",
            letterSpacing: "0.15em",
            marginBottom: "20px",
            opacity: titleProgress,
            fontFamily: FONTS.sans,
          }}
        >
          The Solution
        </div>

        {/* Title */}
        <h2
          style={{
            fontSize: "50px",
            fontWeight: 700,
            color: COLORS.textPrimary,
            textAlign: "center",
            margin: 0,
            marginBottom: "20px",
            opacity: titleProgress,
            letterSpacing: "-0.02em",
            lineHeight: 1.2,
            fontFamily: FONTS.sans,
          }}
        >
          ProofMesh is a{" "}
          <span style={{ color: COLORS.indigo[500] }}>collaborative workspace</span>
          <br />
          where humans and AI explore ideas.
        </h2>

        {/* Subtitle */}
        <p
          style={{
            fontSize: "22px",
            color: COLORS.textSecondary,
            textAlign: "center",
            maxWidth: "650px",
            lineHeight: 1.6,
            opacity: interpolate(frame, [25, 55], [0, 1]),
            fontFamily: FONTS.sans,
          }}
        >
          Verify them. Build a shared graph of knowledge.
        </p>

        {/* Feature cards */}
        <div
          style={{
            display: "flex",
            gap: "24px",
            marginTop: "56px",
          }}
        >
          {FEATURES.map((feature, i) => {
            const cardProgress = spring({
              frame: frame - 50 - i * 12,
              fps,
              config: { damping: 200 },
            });

            return (
              <div
                key={feature.title}
                style={{
                  backgroundColor: COLORS.bgSecondary,
                  borderRadius: "20px",
                  padding: "32px",
                  width: "240px",
                  textAlign: "center",
                  transform: `translateY(${(1 - cardProgress) * 40}px)`,
                  opacity: cardProgress,
                  border: `1px solid ${COLORS.borderPrimary}`,
                }}
              >
                <div
                  style={{
                    width: "64px",
                    height: "64px",
                    borderRadius: "16px",
                    backgroundColor: `${feature.color}15`,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    margin: "0 auto 18px",
                    border: `1px solid ${feature.color}30`,
                  }}
                >
                  <IconComponent type={feature.icon} size={28} color={feature.color} />
                </div>
                <div
                  style={{
                    color: COLORS.textPrimary,
                    fontWeight: 600,
                    fontSize: "17px",
                    marginBottom: "6px",
                    fontFamily: FONTS.sans,
                  }}
                >
                  {feature.title}
                </div>
                <div
                  style={{
                    color: COLORS.textMuted,
                    fontSize: "14px",
                    fontFamily: FONTS.sans,
                  }}
                >
                  {feature.desc}
                </div>
              </div>
            );
          })}
        </div>

        {/* Agents orbiting visualization */}
        <div
          style={{
            position: "absolute",
            right: 140,
            top: "50%",
            transform: "translateY(-50%)",
            opacity: interpolate(frame, [90, 130], [0, 0.7]),
          }}
        >
          <AgentOrbit startFrame={100} />
        </div>
      </div>
    </AbsoluteFill>
  );
};
