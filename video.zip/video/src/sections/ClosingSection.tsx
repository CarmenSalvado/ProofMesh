import React from "react";
import { AbsoluteFill, useCurrentFrame, useVideoConfig, interpolate, spring } from "remotion";
import { GraphBackground } from "../components/GraphBackground";
import { COLORS, FONTS } from "../components/ProofMeshStyles";
import { Brain, Network, Code } from "../components/Icons";

export const ClosingSection: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  const titleProgress = spring({
    frame: frame - 5,
    fps,
    config: { damping: 200 },
  });

  const taglineProgress = spring({
    frame: frame - 40,
    fps,
    config: { damping: 200 },
  });

  const ctaProgress = spring({
    frame: frame - 80,
    fps,
    config: { damping: 200 },
  });

  // Count up animation for stats
  const contributors = Math.min(247, Math.floor(interpolate(frame, [30, 120], [0, 247])));
  const theorems = Math.min(15234, Math.floor(interpolate(frame, [30, 120], [0, 15234])));

  return (
    <AbsoluteFill
      style={{
        backgroundColor: COLORS.bgPrimary,
        overflow: "hidden",
        fontFamily: FONTS.sans,
      }}
    >
      {/* Animated graph background - denser for closing */}
      <div style={{ opacity: 0.3 }}>
        <GraphBackground animated startFrame={0} />
      </div>

      {/* Radial gradient glow */}
      <div
        style={{
          position: "absolute",
          left: "50%",
          top: "40%",
          width: 1000,
          height: 1000,
          transform: "translate(-50%, -50%)",
          background: `radial-gradient(circle, ${COLORS.indigo[500]}20 0%, ${COLORS.emerald[500]}10 40%, transparent 70%)`,
          opacity: interpolate(frame, [0, 60], [0, 0.8]),
        }}
      />

      {/* Main content */}
      <div
        style={{
          position: "absolute",
          inset: 0,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        {/* Stats row */}
        <div
          style={{
            display: "flex",
            gap: "60px",
            marginBottom: "50px",
            opacity: interpolate(frame, [20, 60], [0, 1]),
          }}
        >
          {[
            { value: contributors.toLocaleString(), label: "Contributors", suffix: "+", icon: "network", color: COLORS.indigo[500] },
            { value: theorems.toLocaleString(), label: "Theorems", suffix: "", icon: "code", color: COLORS.emerald[500] },
            { value: "100%", label: "Open Source", suffix: "", icon: "brain", color: COLORS.amber[500] },
          ].map((stat, i) => (
            <div
              key={stat.label}
              style={{
                textAlign: "center",
                transform: `translateY(${interpolate(frame, [20 + i * 10, 60 + i * 10], [20, 0])}px)`,
              }}
            >
              <div style={{ marginBottom: "8px", display: "flex", justifyContent: "center" }}>
                {stat.icon === "network" && <Network size={24} color={stat.color} />}
                {stat.icon === "code" && <Code size={24} color={stat.color} />}
                {stat.icon === "brain" && <Brain size={24} color={stat.color} />}
              </div>
              <div
                style={{
                  fontSize: "42px",
                  fontWeight: 700,
                  color: stat.color,
                  fontFamily: FONTS.sans,
                }}
              >
                {stat.value}{stat.suffix}
              </div>
              <div
                style={{
                  fontSize: "13px",
                  color: COLORS.textMuted,
                  textTransform: "uppercase",
                  letterSpacing: "0.1em",
                  marginTop: "4px",
                  fontFamily: FONTS.sans,
                }}
              >
                {stat.label}
              </div>
            </div>
          ))}
        </div>

        {/* Main tagline */}
        <h2
          style={{
            fontSize: "52px",
            fontWeight: 700,
            color: COLORS.textPrimary,
            textAlign: "center",
            margin: 0,
            lineHeight: 1.2,
            opacity: titleProgress,
            transform: `scale(${0.95 + titleProgress * 0.05})`,
            letterSpacing: "-0.02em",
            fontFamily: FONTS.sans,
          }}
        >
          ProofMesh is{" "}
          <span style={{ color: COLORS.indigo[500] }}>Cursor</span> +{" "}
          <span style={{ color: COLORS.emerald[500] }}>GitHub</span>
          <br />
          for human-AI reasoning.
        </h2>

        {/* Subtitle */}
        <p
          style={{
            fontSize: "24px",
            color: COLORS.textSecondary,
            textAlign: "center",
            maxWidth: "700px",
            lineHeight: 1.6,
            marginTop: "24px",
            opacity: taglineProgress,
            fontFamily: FONTS.sans,
          }}
        >
          We&apos;re building the infrastructure
          <br />
          for collaborative knowledge.
        </p>

        {/* Logo and CTA */}
        <div
          style={{
            marginTop: "60px",
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            gap: "24px",
            opacity: ctaProgress,
            transform: `translateY(${(1 - ctaProgress) * 20}px)`,
          }}
        >
          {/* Logo */}
          <div
            style={{
              display: "flex",
              alignItems: "center",
              gap: "14px",
              padding: "16px 28px",
              backgroundColor: COLORS.bgSecondary,
              border: `1px solid ${COLORS.borderPrimary}`,
              borderRadius: "16px",
              boxShadow: "0 8px 30px rgba(0,0,0,0.4)",
            }}
          >
            <div
              style={{
                width: 44,
                height: 44,
                borderRadius: "12px",
                background: `linear-gradient(135deg, ${COLORS.indigo[500]}, ${COLORS.emerald[500]})`,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                boxShadow: "0 0 60px rgba(99, 102, 241, 0.3)",
              }}
            >
              <Brain size={24} color="#ffffff" />
            </div>
            <span
              style={{
                fontSize: "28px",
                fontWeight: 700,
                color: COLORS.textPrimary,
                letterSpacing: "-0.02em",
                fontFamily: FONTS.sans,
              }}
            >
              ProofMesh
            </span>
          </div>

          {/* URL */}
          <div
            style={{
              fontSize: "16px",
              color: COLORS.textMuted,
              letterSpacing: "0.05em",
              fontFamily: FONTS.sans,
            }}
          >
            proofmesh.io
          </div>
        </div>
      </div>

      {/* Bottom bar */}
      <div
        style={{
          position: "absolute",
          bottom: 0,
          left: 0,
          right: 0,
          height: "4px",
          background: `linear-gradient(90deg, ${COLORS.indigo[500]}, ${COLORS.emerald[500]}, ${COLORS.amber[500]})`,
          opacity: interpolate(frame, [100, 140], [0, 1]),
        }}
      />
    </AbsoluteFill>
  );
};
