import React from "react";
import { AbsoluteFill, useCurrentFrame, useVideoConfig, interpolate, spring } from "remotion";
import { GraphBackground } from "../components/GraphBackground";
import { COLORS, FONTS } from "../components/ProofMeshStyles";
import { Brain } from "../components/Icons";

export const HookSection: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  const bgOpacity = interpolate(frame, [0, 30], [0, 0.2], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });

  const titleProgress = spring({
    frame: frame - 10,
    fps,
    config: { damping: 200 },
  });

  const subtitleProgress = spring({
    frame: frame - 45,
    fps,
    config: { damping: 200 },
  });

  const logoProgress = spring({
    frame: frame - 80,
    fps,
    config: { damping: 200 },
  });

  return (
    <AbsoluteFill
      style={{
        backgroundColor: COLORS.bgPrimary,
        overflow: "hidden",
        fontFamily: FONTS.sans,
      }}
    >
      {/* Animated graph background */}
      <div style={{ opacity: bgOpacity }}>
        <GraphBackground animated startFrame={15} />
      </div>

      {/* Math formulas floating */}
      <div
        style={{
          position: "absolute",
          left: 120,
          top: 180,
          opacity: interpolate(frame, [25, 55], [0, 0.25]),
          fontFamily: FONTS.math,
          fontSize: "22px",
          color: COLORS.textMuted,
          fontStyle: "italic",
          transform: `translateY(${interpolate(frame, [0, 300], [0, -40])}px)`,
        }}
      >
        sum of a_i = S_n
      </div>

      <div
        style={{
          position: "absolute",
          right: 180,
          top: 320,
          opacity: interpolate(frame, [35, 65], [0, 0.25]),
          fontFamily: FONTS.math,
          fontSize: "18px",
          color: COLORS.textMuted,
          fontStyle: "italic",
          transform: `translateY(${interpolate(frame, [0, 300], [0, -30])}px)`,
        }}
      >
        for all x in R: x^2 &gt;= 0
      </div>

      <div
        style={{
          position: "absolute",
          left: 250,
          bottom: 220,
          opacity: interpolate(frame, [45, 75], [0, 0.25]),
          fontFamily: FONTS.math,
          fontSize: "20px",
          color: COLORS.textMuted,
          fontStyle: "italic",
          transform: `translateY(${interpolate(frame, [0, 300], [0, -50])}px)`,
        }}
      >
        {'integral of e^(-x^2) = sqrt(pi)/2'}
      </div>

      {/* Main content */}
      <div
        style={{
          position: "absolute",
          inset: 0,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          textAlign: "center",
        }}
      >
        {/* Title */}
        <h1
          style={{
            fontSize: "68px",
            fontWeight: 700,
            color: COLORS.textPrimary,
            margin: 0,
            lineHeight: 1.15,
            opacity: titleProgress,
            transform: `scale(${0.9 + titleProgress * 0.1})`,
            letterSpacing: "-0.02em",
            fontFamily: FONTS.sans,
          }}
        >
          Math is still done
          <br />
          <span style={{ color: COLORS.textMuted }}>like in the 1800s.</span>
        </h1>

        {/* Subtitle */}
        <p
          style={{
            fontSize: "28px",
            color: COLORS.textSecondary,
            marginTop: "36px",
            maxWidth: "850px",
            lineHeight: 1.5,
            opacity: subtitleProgress,
            fontWeight: 400,
            fontFamily: FONTS.sans,
          }}
        >
          ProofMesh turns ideas into{" "}
          <span style={{ color: COLORS.emerald[500], fontWeight: 600 }}>verified</span>,{" "}
          <span style={{ color: COLORS.indigo[500], fontWeight: 600 }}>collaborative</span>{" "}
          knowledge.
        </p>

        {/* Logo */}
        <div
          style={{
            marginTop: "56px",
            opacity: logoProgress,
            transform: `translateY(${(1 - logoProgress) * 20}px)`,
            display: "flex",
            alignItems: "center",
            gap: "14px",
          }}
        >
          <div
            style={{
              width: 48,
              height: 48,
              borderRadius: "12px",
              background: `linear-gradient(135deg, ${COLORS.indigo[500]}, ${COLORS.emerald[500]})`,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              boxShadow: "0 0 60px rgba(99, 102, 241, 0.3)",
            }}
          >
            <Brain size={26} color="#ffffff" />
          </div>
          <span
            style={{
              fontSize: "32px",
              fontWeight: 700,
              color: COLORS.textPrimary,
              letterSpacing: "-0.02em",
              fontFamily: FONTS.sans,
            }}
          >
            ProofMesh
          </span>
        </div>
      </div>

      {/* Bottom gradient */}
      <div
        style={{
          position: "absolute",
          bottom: 0,
          left: 0,
          right: 0,
          height: "200px",
          background: `linear-gradient(to top, ${COLORS.bgPrimary}, transparent)`,
          pointerEvents: "none",
        }}
      />
    </AbsoluteFill>
  );
};
