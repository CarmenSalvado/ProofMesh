import React from "react";
import { AbsoluteFill, useCurrentFrame, useVideoConfig, interpolate, spring, Sequence } from "remotion";
import { LaTeXEditor } from "../components/MathFormula";
import { GraphCard } from "../components/NodeGraph";
import { AgentThinking } from "../components/AgentBadge";
import { COLORS, FONTS } from "../components/ProofMeshStyles";
import { Bot, Check, MousePointer, Code } from "../components/Icons";

export const CoreDemoSection: React.FC = () => {
  const frame = useCurrentFrame();

  return (
    <AbsoluteFill
      style={{
        backgroundColor: COLORS.bgPrimary,
        overflow: "hidden",
        fontFamily: FONTS.sans,
      }}
    >
      {/* Section label */}
      <div
        style={{
          position: "absolute",
          top: 50,
          left: "50%",
          transform: "translateX(-50%)",
          fontSize: "13px",
          fontWeight: 600,
          color: COLORS.indigo[500],
          textTransform: "uppercase",
          letterSpacing: "0.15em",
          opacity: interpolate(frame, [0, 20], [0, 1]),
          fontFamily: FONTS.sans,
        }}
      >
        Core Demo
      </div>

      {/* Part A: Editor + Chat (0-10s) */}
      <Sequence durationInFrames={300}>
        <EditorDemo />
      </Sequence>

      {/* Part B: Trazabilidad (10-15s) */}
      <Sequence from={300} durationInFrames={150}>
        <TraceabilityDemo />
      </Sequence>

      {/* Part C: Grafo de nodos (15-35s) */}
      <Sequence from={450} durationInFrames={600}>
        <GraphDemo />
      </Sequence>

      {/* Part D: 3Blue1Brown style animation (35-40s) */}
      <Sequence from={1050} durationInFrames={150}>
        <AnimationDemo />
      </Sequence>
    </AbsoluteFill>
  );
};

const EditorDemo: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  const progress = spring({
    frame: frame - 10,
    fps,
    config: { damping: 200 },
  });

  const chatProgress = spring({
    frame: frame - 120,
    fps,
    config: { damping: 200 },
  });

  const acceptProgress = spring({
    frame: frame - 200,
    fps,
    config: { damping: 200 },
  });

  return (
    <div
      style={{
        position: "absolute",
        inset: 0,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
      }}
    >
      {/* Title */}
      <div
        style={{
          position: "absolute",
          top: 100,
          left: "50%",
          transform: "translateX(-50%)",
          textAlign: "center",
          opacity: progress,
        }}
      >
        <h3
          style={{
            fontSize: "36px",
            fontWeight: 700,
            color: COLORS.textPrimary,
            marginBottom: "8px",
            fontFamily: FONTS.sans,
          }}
        >
          Human + AI Co-Writing
        </h3>
        <p style={{ fontSize: "18px", color: COLORS.textMuted, fontFamily: FONTS.sans }}>
          Write LaTeX, get AI suggestions, accept improvements
        </p>
      </div>

      {/* Editor */}
      <div
        style={{
          transform: `translateX(-280px) scale(${progress})`,
          opacity: progress,
        }}
      >
        <LaTeXEditor
          title="theorem.md"
          code={`## Theorem 3.2

Let $f: X \\to Y$ be a continuous
function between topological spaces.

**Proof:**

Suppose $U \\subseteq Y$ is open.
Then $f^{-1}(U)$ is open in X by
definition of continuity.

$\\square$`}
          startFrame={20}
        />
      </div>

      {/* AI Suggestion Panel */}
      <div
        style={{
          position: "absolute",
          right: 280,
          top: 320,
          width: 320,
          backgroundColor: COLORS.bgSecondary,
          border: `1px solid ${COLORS.borderPrimary}`,
          borderRadius: "12px",
          padding: "16px",
          transform: `translateX(${(1 - chatProgress) * 40}px)`,
          opacity: chatProgress,
          boxShadow: "0 8px 30px rgba(0,0,0,0.4)",
        }}
      >
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: "8px",
            marginBottom: "12px",
          }}
        >
          <Bot size={16} color={COLORS.emerald[500]} />
          <span
            style={{
              fontSize: "12px",
              fontWeight: 600,
              color: COLORS.emerald[500],
              textTransform: "uppercase",
              fontFamily: FONTS.sans,
            }}
          >
            Gemini Suggestion
          </span>
        </div>
        <p
          style={{
            fontSize: "13px",
            color: COLORS.textSecondary,
            lineHeight: 1.5,
            marginBottom: "16px",
            fontFamily: FONTS.sans,
          }}
        >
          Consider adding a lemma about compactness. This would make the proof more modular and reusable.
        </p>
        <div style={{ display: "flex", gap: "8px" }}>
          <button
            style={{
              flex: 1,
              padding: "8px 12px",
              borderRadius: "6px",
              border: "none",
              backgroundColor: COLORS.emerald[500],
              color: COLORS.textPrimary,
              fontSize: "12px",
              fontWeight: 600,
              cursor: "pointer",
              transform: `scale(${acceptProgress})`,
              opacity: acceptProgress > 0 ? 1 : 0.5,
              fontFamily: FONTS.sans,
            }}
          >
            Accept
          </button>
          <button
            style={{
              flex: 1,
              padding: "8px 12px",
              borderRadius: "6px",
              border: `1px solid ${COLORS.borderSecondary}`,
              backgroundColor: "transparent",
              color: COLORS.textMuted,
              fontSize: "12px",
              cursor: "pointer",
              fontFamily: FONTS.sans,
            }}
          >
            Reject
          </button>
        </div>
      </div>

      {/* Agent thinking indicator */}
      {frame > 80 && frame < 140 && (
        <div style={{ position: "absolute", right: 400, top: 280 }}>
          <AgentThinking startFrame={80} />
        </div>
      )}
    </div>
  );
};

const TraceabilityDemo: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  const progress = spring({
    frame: frame - 10,
    fps,
    config: { damping: 200 },
  });

  return (
    <div
      style={{
        position: "absolute",
        inset: 0,
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
      }}
    >
      {/* Title */}
      <div
        style={{
          textAlign: "center",
          marginBottom: "50px",
          opacity: progress,
        }}
      >
        <h3
          style={{
            fontSize: "36px",
            fontWeight: 700,
            color: COLORS.textPrimary,
            marginBottom: "8px",
            fontFamily: FONTS.sans,
          }}
        >
          Credit by Design
        </h3>
        <p style={{ fontSize: "18px", color: COLORS.textMuted, fontFamily: FONTS.sans }}>
          Hover any node to see who proposed it
        </p>
      </div>

      {/* Node cards showing attribution */}
      <div
        style={{
          display: "flex",
          gap: "40px",
          alignItems: "center",
        }}
      >
        {/* Node with attribution */}
        <div
          style={{
            backgroundColor: COLORS.bgSecondary,
            border: `1px solid ${COLORS.borderPrimary}`,
            borderRadius: "16px",
            padding: "32px",
            width: 280,
            textAlign: "center",
            transform: `scale(${progress})`,
            opacity: progress,
          }}
        >
          <div
            style={{
              width: 64,
              height: 64,
              borderRadius: "50%",
              backgroundColor: COLORS.amber[500],
              margin: "0 auto 16px",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              fontSize: "24px",
              fontWeight: 700,
              color: "#ffffff",
              boxShadow: `0 0 30px ${COLORS.amber[500]}40`,
              fontFamily: FONTS.sans,
            }}
          >
            T
          </div>
          <div
            style={{
              color: COLORS.textPrimary,
              fontWeight: 600,
              fontSize: "18px",
              marginBottom: "4px",
              fontFamily: FONTS.sans,
            }}
          >
            Theorem 4.1
          </div>
          <div style={{ color: COLORS.textMuted, fontSize: "14px", fontFamily: FONTS.sans }}>
            Compactness implies... 
          </div>

          {/* Attribution tooltip */}
          <div
            style={{
              marginTop: "20px",
              padding: "12px 16px",
              backgroundColor: COLORS.bgTertiary,
              borderRadius: "10px",
              border: `1px solid ${COLORS.borderSecondary}`,
              opacity: interpolate(frame, [60, 100], [0, 1]),
              transform: `translateY(${interpolate(frame, [60, 100], [10, 0])}px)`,
            }}
          >
            <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
              <div
                style={{
                  width: 32,
                  height: 32,
                  borderRadius: "50%",
                  background: `linear-gradient(135deg, ${COLORS.indigo[500]}, ${COLORS.emerald[500]})`,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  fontSize: "14px",
                  fontWeight: 700,
                  color: "#ffffff",
                  fontFamily: FONTS.sans,
                }}
              >
                A
              </div>
              <div style={{ textAlign: "left" }}>
                <div style={{ color: COLORS.textPrimary, fontSize: "13px", fontWeight: 600, fontFamily: FONTS.sans }}>
                  Proposed by Alice
                </div>
                <div style={{ color: COLORS.textMuted, fontSize: "11px", fontFamily: FONTS.sans }}>
                  2 days ago • Verified
                  <Check size={10} color={COLORS.emerald[500]} />
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Arrow */}
        <div
          style={{
            fontSize: "32px",
            color: COLORS.textMuted,
            opacity: interpolate(frame, [80, 120], [0, 1]),
            fontFamily: FONTS.sans,
          }}
        >
          →
        </div>

        {/* Stats */}
        <div
          style={{
            backgroundColor: COLORS.bgSecondary,
            border: `1px solid ${COLORS.borderPrimary}`,
            borderRadius: "16px",
            padding: "24px",
            width: 200,
            opacity: interpolate(frame, [100, 140], [0, 1]),
            transform: `translateX(${interpolate(frame, [100, 140], [30, 0])}px)`,
          }}
        >
          <div style={{ color: COLORS.textFaint, fontSize: "11px", textTransform: "uppercase", letterSpacing: "0.1em", marginBottom: "16px", fontFamily: FONTS.sans }}>
            Contribution Stats
          </div>
          {[
            { label: "Proposals", value: 12 },
            { label: "Verified", value: 8 },
            { label: "Citations", value: 23 },
          ].map((stat, i) => (
            <div
              key={stat.label}
              style={{
                display: "flex",
                justifyContent: "space-between",
                padding: "8px 0",
                borderBottom: i < 2 ? `1px solid ${COLORS.borderPrimary}` : "none",
              }}
            >
              <span style={{ color: COLORS.textMuted, fontSize: "13px", fontFamily: FONTS.sans }}>{stat.label}</span>
              <span style={{ color: COLORS.emerald[500], fontWeight: 600, fontSize: "13px", fontFamily: FONTS.sans }}>
                {stat.value}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

const GraphDemo: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  return (
    <div
      style={{
        position: "absolute",
        inset: 0,
      }}
    >
      {/* Title */}
      <div
        style={{
          position: "absolute",
          top: 80,
          left: "50%",
          transform: "translateX(-50%)",
          textAlign: "center",
          opacity: interpolate(frame, [0, 30], [0, 1]),
        }}
      >
        <h3
          style={{
            fontSize: "36px",
            fontWeight: 700,
            color: COLORS.textPrimary,
            marginBottom: "8px",
            fontFamily: FONTS.sans,
          }}
        >
          Knowledge Graph
        </h3>
        <p style={{ fontSize: "18px", color: COLORS.textMuted, fontFamily: FONTS.sans }}>
          Visual reasoning with clickable nodes
        </p>
      </div>

      {/* Graph visualization */}
      <GraphCard startFrame={30} />

      {/* Feature labels appearing sequentially */}
      <div
        style={{
          position: "absolute",
          bottom: 100,
          left: "50%",
          transform: "translateX(-50%)",
          display: "flex",
          gap: "40px",
        }}
      >
        {[
          { icon: "mouse", text: "Click to explore", delay: 200 },
          { icon: "bot", text: "Agents explore branches", delay: 300 },
          { icon: "code", text: "Verify with Lean", delay: 400 },
        ].map((feature) => {
          const featureProgress = spring({
            frame: frame - feature.delay,
            fps,
            config: { damping: 200 },
          });

          return (
            <div
              key={feature.text}
              style={{
                display: "flex",
                alignItems: "center",
                gap: "10px",
                opacity: featureProgress,
                transform: `translateY(${(1 - featureProgress) * 20}px)`,
              }}
            >
              {feature.icon === "mouse" && <MousePointer size={20} color={COLORS.textSecondary} />}
              {feature.icon === "bot" && <Bot size={20} color={COLORS.textSecondary} />}
              {feature.icon === "code" && <Code size={20} color={COLORS.textSecondary} />}
              <span style={{ color: COLORS.textSecondary, fontSize: "14px", fontFamily: FONTS.sans }}>
                {feature.text}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
};

const AnimationDemo: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  const progress = spring({
    frame: frame - 20,
    fps,
    config: { damping: 200 },
  });

  return (
    <div
      style={{
        position: "absolute",
        inset: 0,
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
      }}
    >
      {/* Title */}
      <div
        style={{
          textAlign: "center",
          marginBottom: "50px",
          opacity: progress,
        }}
      >
        <h3
          style={{
            fontSize: "36px",
            fontWeight: 700,
            color: COLORS.textPrimary,
            marginBottom: "8px",
            fontFamily: FONTS.sans,
          }}
        >
          Visual Explanations
        </h3>
        <p style={{ fontSize: "18px", color: COLORS.textMuted, fontFamily: FONTS.sans }}>
          3Blue1Brown-style animations for complex proofs
        </p>
      </div>

      {/* Animated visualization mockup */}
      <div
        style={{
          width: 700,
          height: 400,
          backgroundColor: COLORS.bgSecondary,
          border: `1px solid ${COLORS.borderPrimary}`,
          borderRadius: "16px",
          overflow: "hidden",
          boxShadow: "0 20px 50px rgba(0,0,0,0.5)",
          position: "relative",
        }}
      >
        {/* Coordinate grid */}
        <svg
          style={{
            position: "absolute",
            inset: 0,
            width: "100%",
            height: "100%",
          }}
        >
          {/* Grid lines */}
          {Array.from({ length: 10 }).map((_, idx) => (
            <g key={`grid-${idx}`}>
              <line
                x1={50 + idx * 60}
                y1={20}
                x2={50 + idx * 60}
                y2={380}
                stroke={COLORS.borderPrimary}
                strokeWidth={1}
                opacity={0.3}
              />
              <line
                x1={20}
                y1={50 + idx * 30}
                x2={680}
                y2={50 + idx * 30}
                stroke={COLORS.borderPrimary}
                strokeWidth={1}
                opacity={0.3}
              />
            </g>
          ))}

          {/* Animated curve */}
          <path
            d="M 50 350 Q 200 50, 350 200 T 650 100"
            fill="none"
            stroke={COLORS.indigo[500]}
            strokeWidth={3}
            strokeDasharray="1000"
            strokeDashoffset={interpolate(frame, [0, 80], [1000, 0])}
            style={{
              filter: `drop-shadow(0 0 10px ${COLORS.indigo[500]}50)`,
            }}
          />

          {/* Animated point */}
          <circle
            cx={interpolate(frame, [0, 80], [50, 350])}
            cy={interpolate(frame, [0, 40, 80], [350, 50, 200])}
            r={8}
            fill={COLORS.emerald[500]}
            opacity={interpolate(frame, [0, 20, 60, 80], [0, 1, 1, 0])}
          />
        </svg>

        {/* Formula overlay */}
        <div
          style={{
            position: "absolute",
            bottom: 20,
            right: 20,
            backgroundColor: COLORS.bgTertiary,
            border: `1px solid ${COLORS.borderSecondary}`,
            borderRadius: "10px",
            padding: "12px 16px",
            opacity: interpolate(frame, [50, 90], [0, 1]),
          }}
        >
          <div
            style={{
              fontFamily: FONTS.math,
              fontSize: "18px",
              color: COLORS.textSecondary,
              fontStyle: "italic",
            }}
          >
            f(x) = x^3 - 3x + 1
          </div>
        </div>
      </div>
    </div>
  );
};
