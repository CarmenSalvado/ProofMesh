import React from "react";
import { AbsoluteFill, useCurrentFrame, useVideoConfig, interpolate, spring, Easing } from "remotion";
import { COLORS, FONTS } from "../components/ProofMeshStyles";
import { FileText, MessageSquare, User, AlertTriangle } from "../components/Icons";

const PROBLEMS = [
  { icon: "filetext", title: "Chaotic Documents", color: COLORS.zinc[500], delay: 0 },
  { icon: "messagesquare", title: "Lost in Chat", color: COLORS.amber[500], delay: 15 },
  { icon: "user", title: "No Attribution", color: COLORS.indigo[500], delay: 30 },
  { icon: "alerttriangle", title: "Fragile Proofs", color: "#f43f5e", delay: 45 },
];

const IconComponent: React.FC<{ type: string; size?: number; color?: string }> = ({ type, size = 24, color }) => {
  switch (type) {
    case "filetext": return <FileText size={size} color={color} />;
    case "messagesquare": return <MessageSquare size={size} color={color} />;
    case "user": return <User size={size} color={color} />;
    case "alerttriangle": return <AlertTriangle size={size} color={color} />;
    default: return <FileText size={size} color={color} />;
  }
};

export const ProblemSection: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  const titleProgress = spring({
    frame: frame - 5,
    fps,
    config: { damping: 200 },
  });

  return (
    <AbsoluteFill
      style={{
        backgroundColor: COLORS.bgPrimary,
        overflow: "hidden",
        fontFamily: FONTS.sans,
      }}
    >
      {/* Background noise pattern */}
      <div
        style={{
          position: "absolute",
          inset: 0,
          opacity: 0.03,
          backgroundImage: `radial-gradient(circle at 2px 2px, ${COLORS.zinc[500]} 1px, transparent 0)`,
          backgroundSize: "32px 32px",
        }}
      />

      {/* Main content */}
      <div
        style={{
          position: "absolute",
          inset: 0,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          padding: "80px",
        }}
      >
        {/* Section label */}
        <div
          style={{
            fontSize: "13px",
            fontWeight: 600,
            color: "#f43f5e",
            textTransform: "uppercase",
            letterSpacing: "0.15em",
            marginBottom: "20px",
            opacity: titleProgress,
            fontFamily: FONTS.sans,
          }}
        >
          The Problem
        </div>

        {/* Title */}
        <h2
          style={{
            fontSize: "54px",
            fontWeight: 700,
            color: COLORS.textPrimary,
            textAlign: "center",
            margin: 0,
            marginBottom: "16px",
            opacity: titleProgress,
            letterSpacing: "-0.02em",
            fontFamily: FONTS.sans,
          }}
        >
          Today, math collaboration is{" "}
          <span style={{ color: "#f43f5e" }}>messy</span>.
        </h2>

        {/* Subtitle */}
        <p
          style={{
            fontSize: "22px",
            color: COLORS.textSecondary,
            textAlign: "center",
            maxWidth: "700px",
            lineHeight: 1.6,
            opacity: interpolate(frame, [20, 50], [0, 1]),
            fontFamily: FONTS.sans,
          }}
        >
          Ideas are lost, proofs are fragile, and reuse is impossible.
        </p>

        {/* Problem cards */}
        <div
          style={{
            display: "flex",
            gap: "20px",
            marginTop: "60px",
            flexWrap: "wrap",
            justifyContent: "center",
          }}
        >
          {PROBLEMS.map((problem, i) => {
            const cardProgress = spring({
              frame: frame - 45 - problem.delay,
              fps,
              config: { damping: 200 },
            });

            const floatY = interpolate(
              frame + i * 80,
              [0, 30, 60],
              [0, -6, 0],
              { extrapolateRight: "extend", easing: Easing.inOut(Easing.sin) }
            );

            return (
              <div
                key={problem.title}
                style={{
                  backgroundColor: COLORS.bgSecondary,
                  borderRadius: "16px",
                  padding: "28px",
                  width: "200px",
                  textAlign: "center",
                  transform: `translateY(${floatY}px) scale(${cardProgress})`,
                  opacity: cardProgress,
                  border: `1px solid ${problem.color}30`,
                  boxShadow: `0 20px 40px -15px ${problem.color}20`,
                }}
              >
                <div style={{ marginBottom: "14px", display: "flex", justifyContent: "center" }}>
                  <IconComponent type={problem.icon} size={42} color={problem.color} />
                </div>
                <div
                  style={{
                    color: problem.color,
                    fontWeight: 600,
                    fontSize: "15px",
                    fontFamily: FONTS.sans,
                  }}
                >
                  {problem.title}
                </div>
              </div>
            );
          })}
        </div>

        {/* Decorative chaotic elements */}
        <div
          style={{
            position: "absolute",
            top: 80,
            right: 100,
            fontSize: "56px",
            opacity: 0.06,
            transform: `rotate(${interpolate(frame, [0, 300], [0, 35])}deg)`,
          }}
        >
          <FileText size={56} color={COLORS.textMuted} />
        </div>
        <div
          style={{
            position: "absolute",
            bottom: 120,
            left: 60,
            fontSize: "40px",
            opacity: 0.06,
            transform: `rotate(${interpolate(frame, [0, 300], [0, -25])}deg)`,
          }}
        >
          <MessageSquare size={40} color={COLORS.textMuted} />
        </div>
      </div>
    </AbsoluteFill>
  );
};
