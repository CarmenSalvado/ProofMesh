import React from "react";
import { AbsoluteFill, useCurrentFrame, useVideoConfig, interpolate, spring } from "remotion";
import { SocialFeed, UserProfile } from "../components/SocialFeed";
import { COLORS, FONTS } from "../components/ProofMeshStyles";
import { Network, Users, Check, FileText } from "../components/Icons";

export const PlatformSection: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  const titleProgress = spring({
    frame: frame - 5,
    fps,
    config: { damping: 200 },
  });

  return (
    <AbsoluteFill
      style={{
        backgroundColor: COLORS.bgPrimary,
        overflow: "hidden",
        fontFamily: FONTS.sans,
      }}
    >
      {/* Main content */}
      <div
        style={{
          position: "absolute",
          inset: 0,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        {/* Section label */}
        <div
          style={{
            fontSize: "13px",
            fontWeight: 600,
            color: COLORS.amber[500],
            textTransform: "uppercase",
            letterSpacing: "0.15em",
            marginBottom: "20px",
            opacity: titleProgress,
            fontFamily: FONTS.sans,
          }}
        >
          The Platform
        </div>

        {/* Title */}
        <h2
          style={{
            fontSize: "48px",
            fontWeight: 700,
            color: COLORS.textPrimary,
            textAlign: "center",
            margin: 0,
            marginBottom: "16px",
            opacity: titleProgress,
            letterSpacing: "-0.02em",
            fontFamily: FONTS.sans,
          }}
        >
          Open-source collaboration
          <br />
          <span style={{ color: COLORS.amber[500] }}>for reasoning</span>
        </h2>

        {/* Subtitle */}
        <p
          style={{
            fontSize: "20px",
            color: COLORS.textSecondary,
            textAlign: "center",
            maxWidth: "600px",
            lineHeight: 1.6,
            opacity: interpolate(frame, [25, 55], [0, 1]),
            marginBottom: "60px",
            fontFamily: FONTS.sans,
          }}
        >
          Profiles, activity feeds, forks, and stars — everything you expect from a modern platform.
        </p>

        {/* Three columns layout */}
        <div
          style={{
            display: "flex",
            gap: "40px",
            alignItems: "flex-start",
          }}
        >
          {/* Left: User Profiles */}
          <div style={{ position: "relative", width: 220, height: 400 }}>
            <UserProfile
              name="Alice"
              role="Mathematician"
              contributions={147}
              startFrame={50}
              x={110}
              y={120}
            />
            <UserProfile
              name="Bob"
              role="Researcher"
              contributions={89}
              startFrame={100}
              x={110}
              y={320}
            />
          </div>

          {/* Center: Activity Feed */}
          <div
            style={{
              width: 480,
              backgroundColor: COLORS.bgSecondary,
              border: `1px solid ${COLORS.borderPrimary}`,
              borderRadius: "16px",
              overflow: "hidden",
              boxShadow: "0 20px 50px rgba(0,0,0,0.5)",
            }}
          >
            {/* Header */}
            <div
              style={{
                backgroundColor: COLORS.bgTertiary,
                borderBottom: `1px solid ${COLORS.borderPrimary}`,
                padding: "16px 20px",
                display: "flex",
                alignItems: "center",
                gap: "10px",
              }}
            >
              <Network size={18} color={COLORS.textSecondary} />
              <span
                style={{
                  fontSize: "14px",
                  fontWeight: 600,
                  color: COLORS.textPrimary,
                  fontFamily: FONTS.sans,
                }}
              >
                Activity Feed
              </span>
            </div>

            {/* Feed content */}
            <div style={{ padding: "16px" }}>
              <SocialFeed startFrame={80} />
            </div>
          </div>

          {/* Right: Stats */}
          <div style={{ width: 200 }}>
            {[
              { label: "Active Users", value: "2.4k", icon: "users", color: COLORS.indigo[500], delay: 120 },
              { label: "Theorems", value: "15.7k", icon: "filetext", color: COLORS.amber[500], delay: 150 },
              { label: "Verified", value: "12.3k", icon: "check", color: COLORS.emerald[500], delay: 180 },
            ].map((stat) => {
              const statProgress = spring({
                frame: frame - stat.delay,
                fps,
                config: { damping: 200 },
              });

              return (
                <div
                  key={stat.label}
                  style={{
                    backgroundColor: COLORS.bgSecondary,
                    border: `1px solid ${COLORS.borderPrimary}`,
                    borderRadius: "12px",
                    padding: "20px",
                    marginBottom: "12px",
                    transform: `translateX(${(1 - statProgress) * 30}px)`,
                    opacity: statProgress,
                  }}
                >
                  <div style={{ marginBottom: "8px" }}>
                    {stat.icon === "users" && <Users size={20} color={stat.color} />}
                    {stat.icon === "filetext" && <FileText size={20} color={stat.color} />}
                    {stat.icon === "check" && <Check size={20} color={stat.color} />}
                  </div>
                  <div
                    style={{
                      fontSize: "28px",
                      fontWeight: 700,
                      color: stat.color,
                      fontFamily: FONTS.sans,
                    }}
                  >
                    {stat.value}
                  </div>
                  <div style={{ fontSize: "12px", color: COLORS.textMuted, fontFamily: FONTS.sans }}>{stat.label}</div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </AbsoluteFill>
  );
};
