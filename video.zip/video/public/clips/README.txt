Drop your recorded app clips here.

Suggested names:
- clip-01.mp4
- clip-02.mp4
- clip-03.mp4

Then set src values in `video/src/CleanRoot.tsx` under the `VibrantMinimalClips` composition defaultProps.
Example:
{ label: "Canvas exploration", src: "/clips/clip-01.mp4" }
