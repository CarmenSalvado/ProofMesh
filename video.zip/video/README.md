# ProofMesh Demo Video

Video promocional para ProofMesh creado con Remotion.

## 🎬 Estructura del Video (2:30 min)

Siguiendo el guion proporcionado:

| Sección | Tiempo | Frames | Descripción |
|---------|--------|--------|-------------|
| 1. Hook | 0-10s | 300 | Impacto inmediato con grafo animado |
| 2. Problema | 10-25s | 450 | Documentos caóticos, chat perdido |
| 3. Solución | 25-45s | 600 | Workspace, grafo, agentes |
| 4. Core Demo | 45-90s | 1350 | Editor, trazabilidad, grafo, animaciones |
| 5. Plataforma | 90-110s | 600 | Perfiles, feed, estadísticas |
| 6. Gemini 3 | 110-130s | 600 | Agentes AI, human-in-the-loop |
| 7. Cierre | 130-150s | 600 | Logo, tagline, estadísticas |

**Total: ~4,200 frames @ 30fps = 2:20 minutos**

## 🚀 Comandos

```bash
# Iniciar el studio de Remotion
npm run dev

# Verificar código
npm run lint

# Renderizar el video completo
npx remotion render ProofMeshDemo

# Renderizar una sección específica
npx remotion render 01-Hook
npx remotion render 04-CoreDemo

# Renderizar GIF estilo thumbnail de ProofMesh
npx remotion render src/index.ts ProofMeshMathGif ../images/proofmesh-math.gif --codec=gif --port=3101
```

## 🎨 Diseño

El video sigue el **sistema de diseño Prism** de ProofMesh:

- **Background**: `#0a0a0a` / `#0d0d0d`
- **Acento**: Índigo `#6366f1` + Esmeralda `#10b981`
- **Texto**: `#fafafa` (primario), `#a0a0a0` (secundario)
- **Bordes**: `#1a1a1a`, `#252525`
- **Tipografía**: Inter (texto), JetBrains Mono (código), Newsreader (matemáticas)

## 📁 Estructura

```
src/
├── components/
│   ├── ProofMeshStyles.ts    # Sistema de diseño
│   ├── AnimatedText.tsx      # Texto animado
│   ├── GraphBackground.tsx   # Grafo de fondo
│   ├── MathFormula.tsx       # Fórmulas y editor LaTeX
│   ├── AgentBadge.tsx        # Badges de agentes
│   ├── NodeGraph.tsx         # Visualización del grafo
│   └── SocialFeed.tsx        # Feed de actividad
├── sections/
│   ├── HookSection.tsx       # Sección 1: Hook
│   ├── ProblemSection.tsx    # Sección 2: Problema
│   ├── SolutionSection.tsx   # Sección 3: Solución
│   ├── CoreDemoSection.tsx   # Sección 4: Demo
│   ├── PlatformSection.tsx   # Sección 5: Plataforma
│   ├── GeminiSection.tsx     # Sección 6: Gemini
│   └── ClosingSection.tsx    # Sección 7: Cierre
├── Root.tsx                  # Composición principal
└── index.css                 # Estilos globales
```

## 🎯 Features del Video

- ✅ Transiciones suaves entre secciones
- ✅ Animaciones basadas en `useCurrentFrame()`
- ✅ Estilo consistente con la plataforma ProofMesh
- ✅ Visualización del grafo de conocimiento
- ✅ Editor LaTeX animado
- ✅ Agentes AI orbitando
- ✅ Efectos de brillo y sombras
- ✅ Texto tipográfico matemático

## 📝 Notas

- El video está diseñado para resolución 1920x1080 (Full HD)
- Frame rate: 30fps
- Usa `@remotion/transitions` para transiciones entre escenas
- Las animaciones son determinísticas (seed-based) para reproducibilidad
